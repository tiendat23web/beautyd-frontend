import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  Search,
  MapPin,
  Phone,
  Mail,
  Heart,
  Menu,
  X,
  User,
  Settings,
  LogOut,
  History,
  ChevronDown,
  MessageCircle,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { searchServices } from "../services/servicesService";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchSuggestions, setShowSearchSuggestions] = useState(false);
  const [searchSuggestions, setSearchSuggestions] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const navigate = useNavigate();

  const dropdownRef = useRef(null);
  const searchRef = useRef(null);
  const debounceTimerRef = useRef(null);

  // Mock user data
  const { user, isAuthenticated, logout } = useAuth();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSearchSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Cleanup debounce timer on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, []);

  // Search services using API
  const fetchSearchSuggestions = async (query) => {
    try {
      const response = await searchServices(query);
      if (response.status === 200) {
        // Return service names as suggestions
        return response.data.map((service) => ({
          id: service.id,
          name: service.name,
        }));
      }
      return [];
    } catch (error) {
      console.error("Search error:", error);
      return [];
    }
  };
  const handleSuggestionClick = useCallback(
    (suggestion, e) => {
      console.log("🔍 handleSuggestionClick called with:", suggestion);
      
      // Ngừng các sự kiện khác để tránh xung đột
      if (e && e.stopPropagation) {
        e.stopPropagation();
        console.log("✅ Event propagation stopped");
      }
      if (e && e.preventDefault) {
        e.preventDefault();
        console.log("✅ Default behavior prevented");
      }

      if (!suggestion?.id) {
        console.warn("⚠️ Dịch vụ không có ID hợp lệ:", suggestion);
        return;
      }

      console.log(`🚀 Navigating to: /service/${suggestion.id}`);

      // 1. Ẩn dropdown trước
      setShowSearchSuggestions(false);

      // 2. Xóa query hoặc set query bằng tên dịch vụ (tùy bạn chọn)
      setSearchQuery("");

      // 3. Chuyển trang
      navigate(`/service/${suggestion.id}`);
      console.log("✅ Navigate function called");
    },
    [navigate],
  );

  // Handle search with debounce
  const handleSearchChange = async (e) => {
    const value = e.target.value;
    setSearchQuery(value);

    // Show suggestions dropdown
    if (value.trim()) {
      setShowSearchSuggestions(true);
      setIsSearching(true);
    } else {
      setShowSearchSuggestions(false);
      setSearchSuggestions([]);
      setIsSearching(false);
      return;
    }

    // Clear existing timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Set new timer for debounce (300ms)
    debounceTimerRef.current = setTimeout(async () => {
      try {
        const results = await fetchSearchSuggestions(value);
        setSearchSuggestions(results);
        setIsSearching(false);
      } catch (error) {
        console.error("Search error:", error);
        setIsSearching(false);
      }
    }, 300);
  };

  // Handle search submission
  const handleSearchSubmit = (query) => {
    setSearchQuery(query);
    setShowSearchSuggestions(false);
    // Navigate to search results page
    navigate(`/search?q=${encodeURIComponent(query)}`);
  };

  // Handle search on Enter
  const handleKeyPress = (e) => {
    if (e.key === "Enter" && searchQuery.trim()) {
      handleSearchSubmit(searchQuery);
    }
  };

  // Handle trending search click
  const handleTrendingClick = (keyword) => {
    setSearchQuery(keyword);
    handleSearchSubmit(keyword);
  };

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!user?.fullName) return "U";
    const names = user.fullName.split(" ");
    if (names.length >= 2) {
      return names[0][0] + names[names.length - 1][0];
    }
    return names[0][0];
  };

  const handleLocationClick = () => {
    const location = "Ho Chi Minh City, Vietnam";
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`;
    window.open(mapsUrl, "_blank");
  };

  return (
<header className="bg-white shadow-sm sticky top-0 z-50" ref={searchRef}>      {/* Top Bar */}
      <div className="bg-purple-600 text-white py-2 px-4 text-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Phone className="w-4 h-4" />
              1900 6483
            </span>
            <span className="hidden md:flex items-center gap-1">
              <Mail className="w-4 h-4" />
              support@beautyx.vn
            </span>
          </div>

          <div className="flex items-center gap-3">
            {!isAuthenticated ? (
              <>
                <button
                  className="hover:text-purple-200 transition-colors"
                  onClick={() => navigate("/login")}
                >
                  Đăng nhập
                </button>
                <button
                  className="bg-white text-purple-600 px-3 py-1 rounded-full text-xs font-semibold hover:bg-purple-50 transition-colors"
                  onClick={() => navigate("/register")}
                >
                  Đăng ký ngay
                </button>
              </>
            ) : (
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center gap-2 hover:text-purple-200 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-white text-purple-600 flex items-center justify-center font-semibold text-sm">
                    {getUserInitials()}
                  </div>
                  <span className="hidden md:inline">
                    {user?.fullName || "User"}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${
                      isDropdownOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {isDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg py-2 text-gray-800">
                    <div className="px-4 py-3 border-b border-gray-100">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-lg">
                          {getUserInitials()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-gray-900 truncate">
                            {user?.fullName || "User"}
                          </p>
                          <p className="text-xs text-gray-500 truncate">
                            {user?.email}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="py-1">
                      <button
                        onClick={() => {
                          navigate("/profile");
                          setIsDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                      >
                        <User className="w-4 h-4 text-gray-500" />
                        Thông tin cá nhân
                      </button>

                      {/* Role-based Dashboard Link */}
                      {user?.role === 'ADMIN' && (
                        <button
                          onClick={() => {
                            navigate("/admin/dashboard");
                            setIsDropdownOpen(false);
                          }}
                          className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                        >
                          <Settings className="w-4 h-4 text-gray-500" />
                          Admin Dashboard
                        </button>
                      )}

                      {user?.role === 'PROVIDER' && (
                        <button
                          onClick={() => {
                            navigate("/provider/dashboard");
                            setIsDropdownOpen(false);
                          }}
                          className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                        >
                          <Settings className="w-4 h-4 text-gray-500" />
                          Provider Dashboard
                        </button>
                      )}

                      {/* <button
                        onClick={() => {
                          navigate("/my-bookings");
                          setIsDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                      >
                        <Calendar className="w-4 h-4 text-gray-500" />
                        Đơn đặt chỗ của tôi
                      </button> */}

                      <button
                        onClick={() => {
                          navigate("/favorites");
                          setIsDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                      >
                        <Heart className="w-4 h-4 text-gray-500" />
                        Yêu thích
                      </button>

                      <button
                        onClick={() => {
                          navigate("/bookings");
                          setIsDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                      >
                        <History className="w-4 h-4 text-gray-500" />
                        Lịch sử đặt chỗ
                      </button>

                      <button
                        onClick={() => {
                          navigate("/messages");
                          setIsDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                      >
                        <MessageCircle className="w-4 h-4 text-gray-500" />
                        Tin nhắn
                      </button>

                      <button
                        onClick={() => {
                          navigate("/notifications");
                          setIsDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-purple-50 transition-colors flex items-center gap-3"
                      >
                        <Settings className="w-4 h-4 text-gray-500" />
                        Thông báo
                      </button>
                    </div>

                    {/* Logout */}
                    <div className="border-t border-gray-100 pt-1">
                      <button
                        onClick={() => {
                          logout();
                          navigate("/login");
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center gap-3"
                      >
                        <LogOut className="w-4 h-4" />
                        Đăng xuất
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 cursor-pointer">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">B</span>
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              BeautyX
            </span>
          </Link>

          {/* Search Bar with Autocomplete */}
          <div className="hidden md:flex flex-1 max-w-xl mx-8">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Tìm dịch vụ làm đẹp..."
                value={searchQuery}
                onChange={handleSearchChange}
                onKeyPress={handleKeyPress}
                onFocus={() => {
                  if (searchQuery.trim()) {
                    setShowSearchSuggestions(true);
                  }
                }}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              <Search
                className="absolute left-3 top-2.5 w-5 h-5 text-gray-400 cursor-pointer hover:text-purple-600 transition-colors"
                onClick={() =>
                  searchQuery.trim() && handleSearchSubmit(searchQuery)
                }
              />

              {/* Search Suggestions Dropdown */}
              {showSearchSuggestions && searchQuery.trim() && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 max-h-96 overflow-y-auto z-50">
                  {/* Search Results */}
                  <div className="p-3">
                    {isSearching ? (
                      <div className="text-center py-4 text-gray-500 text-sm">
                        Đang tìm kiếm...
                      </div>
                    ) : searchSuggestions.length > 0 ? (
                      <>
                        <div className="text-xs text-gray-500 mb-2 px-3">
                          Kết quả tìm kiếm
                        </div>
                        {searchSuggestions.map((suggestion, idx) => (
                          <button
                            key={suggestion.id || idx}
                            onMouseDown={(e) => {
                              e.preventDefault(); 
                              e.stopPropagation();
                              console.log('🖱️ Desktop: Click detected', suggestion);
                              handleSuggestionClick(suggestion, e);
                            }}
                            className="w-full text-left px-3 py-2 hover:bg-purple-50 rounded-md transition-colors flex items-center gap-2 group cursor-pointer"
                          >
                            <Search className="w-4 h-4 text-gray-400 group-hover:text-purple-600" />
                            <span className="text-sm text-gray-700 group-hover:text-purple-600">
                              {suggestion.name}
                            </span>
                          </button>
                        ))}
                      </>
                    ) : (
                      <div className="text-center py-4 text-gray-500 text-sm">
                        Không tìm thấy kết quả
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Nav Icons */}
          <div className="flex items-center gap-4">
            <button
              onClick={handleLocationClick}
              className="hidden md:flex flex-col items-center text-gray-600 hover:text-purple-600 transition-colors"
            >
              <MapPin className="w-6 h-6" />
              <span className="text-xs mt-1">Địa điểm</span>
            </button>
            <button className="flex flex-col items-center text-gray-600 hover:text-purple-600 transition-colors"
            onClick = {() =>{
              navigate('/favorites');
            }}
            >
              <Heart className="w-6 h-6" />
              <span className="text-xs mt-1">Yêu thích</span>
            </button>
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden mt-3" >
          <div className="relative">
            <input
              type="text"
              placeholder="Tìm dịch vụ làm đẹp..."
              value={searchQuery}
              onChange={handleSearchChange}
              onKeyPress={handleKeyPress}
              onFocus={() => {
                if (searchQuery.trim()) {
                  setShowSearchSuggestions(true);
                }
              }}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <Search
              className="absolute left-3 top-2.5 w-5 h-5 text-gray-400 cursor-pointer hover:text-purple-600 transition-colors"
              onClick={() =>
                searchQuery.trim() && handleSearchSubmit(searchQuery)
              }
            />

            {/* Mobile Search Suggestions */}
            {showSearchSuggestions && searchQuery.trim() && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 max-h-80 overflow-y-auto z-50">
                <div className="p-3">
                  {isSearching ? (
                    <div className="text-center py-4 text-gray-500 text-sm">
                      Đang tìm kiếm...
                    </div>
                  ) : searchSuggestions.length > 0 ? (
                    <>
                      <div className="text-xs text-gray-500 mb-2 px-3">
                        Kết quả tìm kiếm
                      </div>
                      {searchSuggestions.map((suggestion, idx) => (
                        <button
                          key={suggestion.id || idx}
                          onMouseDown={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            console.log('📱 Mobile: Click detected', suggestion);
                            handleSuggestionClick(suggestion, e);
                          }}
                          className="w-full text-left px-3 py-2 hover:bg-purple-50 rounded-md transition-colors flex items-center gap-2 group cursor-pointer"
                        >
                          <Search className="w-4 h-4 text-gray-400 group-hover:text-purple-600" />
                          <span className="text-sm text-gray-700 group-hover:text-purple-600">
                            {suggestion.name}
                          </span>
                        </button>
                      ))}
                    </>
                  ) : (
                    <div className="text-center py-4 text-gray-500 text-sm">
                      Không tìm thấy kết quả
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Category Menu */}
      <nav className="border-t border-gray-200 hidden md:block">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-6 py-3 overflow-x-auto">
            <Link
              to="/"
              className="text-sm font-medium text-purple-600 hover:text-purple-700 whitespace-nowrap transition-colors"
            >
              Trang chủ
            </Link>
            <Link
              to="/"
              className="text-sm text-gray-600 hover:text-purple-600 whitespace-nowrap transition-colors"
            >
              Khuyến mãi HOT
            </Link>
            <Link
              to="/"
              className="text-sm text-gray-600 hover:text-purple-600 whitespace-nowrap transition-colors"
            >
              Gần bạn
            </Link>
            <Link
              to="/"
              className="text-sm text-gray-600 hover:text-purple-600 whitespace-nowrap transition-colors"
            >
              Dịch vụ nổi bật
            </Link>
            <Link
              to="/"
              className="text-sm text-gray-600 hover:text-purple-600 whitespace-nowrap transition-colors"
            >
              Blog làm đẹp
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-gray-200 bg-white">
          <nav className="px-4 py-3 space-y-2">
            <Link
              to="/"
              className="block py-2 text-sm font-medium text-purple-600"
            >
              Trang chủ
            </Link>
            <Link to="/" className="block py-2 text-sm text-gray-600">
              Khuyến mãi HOT
            </Link>
            <Link to="/" className="block py-2 text-sm text-gray-600">
              Gần bạn
            </Link>
            <Link to="/" className="block py-2 text-sm text-gray-600">
              Dịch vụ nổi bật
            </Link>
            <Link to="/" className="block py-2 text-sm text-gray-600">
              Blog làm đẹp
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
