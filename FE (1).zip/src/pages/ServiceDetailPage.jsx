import React, { useState, useEffect } from "react";
import {
  Clock,
  MapPin,
  Star,
  Phone,
  Calendar,
  ChevronLeft,
  ChevronRight,
  User,
  Heart,
  Share2,
  BadgeCheck,
  MessageCircle,
  ArrowRight,
} from "lucide-react";
import { useParams, useNavigate } from "react-router-dom";
import { getServicesById, getServicesByProvider } from "../services/servicesService";
import { createBooking, getBookedTimeSlots } from "../services/bookingService";
import { useAuth } from "../contexts/AuthContext";
import { toast } from "react-toastify";
import Header from "../components/Header";

const ServiceDetailPage = () => {
  const { serviceId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [service, setService] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showAllReviews, setShowAllReviews] = useState(false);

  // Booking form state
  const [bookingDate, setBookingDate] = useState("");
  const [bookingTime, setBookingTime] = useState("");
  const [bookingNotes, setBookingNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [bookedTimeSlots, setBookedTimeSlots] = useState([]);
  const [loadingBookedTimes, setLoadingBookedTimes] = useState(false);
  const [providerServices, setProviderServices] = useState([]);
  const [loadingProviderServices, setLoadingProviderServices] = useState(false);

  useEffect(() => {
    fetchServiceDetail();
  }, [serviceId]);

  useEffect(() => {
    if (bookingDate && serviceId) {
      fetchBookedTimes();
    } else {
      setBookedTimeSlots([]);
    }
  }, [bookingDate, serviceId]);

  const fetchServiceDetail = async () => {
    try {
      const response = await getServicesById(serviceId);
      setService(response.data);
      
      // Fetch other services from the same provider
      if (response.data?.provider?.id) {
        fetchProviderServices(response.data.provider.id);
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error fetching service:", error);
      setLoading(false);
    }
  };

  const fetchProviderServices = async (providerId) => {
    try {
      setLoadingProviderServices(true);
      const response = await getServicesByProvider(providerId);
      if (response.data) {
        // Filter out the current service
        const otherServices = response.data.filter(s => s.id !== parseInt(serviceId));
        setProviderServices(otherServices);
      }
    } catch (error) {
      console.error("Error fetching provider services:", error);
      setProviderServices([]);
    } finally {
      setLoadingProviderServices(false);
    }
  };

  const fetchBookedTimes = async () => {
    try {
      setLoadingBookedTimes(true);
      const response = await getBookedTimeSlots(serviceId, bookingDate);
      // Response should contain array of booked times like ["09:00", "14:00", ...]
      setBookedTimeSlots(response.bookedTimes || []);
    } catch (error) {
      console.error("Error fetching booked times:", error);
      setBookedTimeSlots([]);
    } finally {
      setLoadingBookedTimes(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(price);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("vi-VN", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const nextImage = () => {
    if (service?.images) {
      setCurrentImageIndex((prev) => (prev + 1) % service.images.length);
    }
  };

  const prevImage = () => {
    if (service?.images) {
      setCurrentImageIndex(
        (prev) => (prev - 1 + service.images.length) % service.images.length
      );
    }
  };

  const calculateAverageRating = () => {
    if (!service?.reviews || service.reviews.length === 0) return 0;
    const sum = service.reviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / service.reviews.length).toFixed(1);
  };

  const renderStars = (rating) => {
    return [...Array(5)].map((_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${
          index < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
        }`}
      />
    ));
  };

  const isTimeSlotBooked = (time) => {
    return bookedTimeSlots.includes(time);
  };

  const handleBookingSubmit = async () => {
    // Validation
    if (!user) {
      toast.error("Vui lòng đăng nhập để đặt lịch");
      navigate("/login");
      return;
    }

    if (!bookingDate) {
      toast.error("Vui lòng chọn ngày");
      return;
    }

    if (!bookingTime) {
      toast.error("Vui lòng chọn giờ");
      return;
    }

    try {
      setSubmitting(true);

      // Combine date and time
      const [hours, minutes] = bookingTime.split(":");
      const bookingDateTime = new Date(bookingDate);
      bookingDateTime.setHours(parseInt(hours), parseInt(minutes), 0);

      const bookingData = {
        serviceId: parseInt(serviceId),
        bookingDate: bookingDateTime.toISOString(),
        notes: bookingNotes.trim() || undefined,
      };

      const response = await createBooking(bookingData);
      console.log(response.status);
      
      if (response.status === 400) {
        toast.error(
          response.data.error || "Đặt lịch thất bại. Vui lòng thử lại"
        );
        setSubmitting(false);
        return;
      }
      toast.success("Đặt lịch thành công!");

      // Reset form
      setBookingDate("");
      setBookingTime("");
      setBookingNotes("");

      // Navigate to bookings page
      setTimeout(() => {
        navigate("/bookings");
      }, 1500);
    } catch (error) {
      console.error("Booking error:", error);
      // Display the error message from backend or a fallback message
      const errorMessage =
        error?.error || error?.message || "Đặt lịch thất bại. Vui lòng thử lại";
      toast.error(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Đang tải thông tin...</p>
        </div>
      </div>
    );
  }

  if (!service) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Không tìm thấy dịch vụ</p>
      </div>
    );
  }

  const avgRating = calculateAverageRating();
  const displayReviews = showAllReviews
    ? service.reviews
    : service.reviews?.slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Images & Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <div className="bg-white rounded-2xl shadow-md overflow-hidden">
              <div className="relative aspect-video bg-gray-200">
                {service.images && service.images.length > 0 && (
                  <>
                    <img
                      src={service.images[currentImageIndex].imageUrl}
                      alt={service.name}
                      className="w-full h-full object-cover"
                    />
                    {service.images.length > 1 && (
                      <>
                        <button
                          onClick={prevImage}
                          className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg"
                        >
                          <ChevronLeft className="w-6 h-6" />
                        </button>
                        <button
                          onClick={nextImage}
                          className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg"
                        >
                          <ChevronRight className="w-6 h-6" />
                        </button>
                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                          {service.images.map((_, index) => (
                            <button
                              key={index}
                              onClick={() => setCurrentImageIndex(index)}
                              className={`w-2 h-2 rounded-full transition-all ${
                                index === currentImageIndex
                                  ? "bg-white w-8"
                                  : "bg-white/50"
                              }`}
                            />
                          ))}
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>

              {/* Thumbnails */}
              {service.images && service.images.length > 1 && (
                <div className="p-4 grid grid-cols-4 gap-2">
                  {service.images.map((image, index) => (
                    <button
                      key={image.id}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`aspect-video rounded-lg overflow-hidden border-2 transition-all ${
                        index === currentImageIndex
                          ? "border-purple-600"
                          : "border-transparent"
                      }`}
                    >
                      <img
                        src={image.imageUrl}
                        alt=""
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Service Info */}
            <div className="bg-white rounded-2xl shadow-md p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">
                      {service.category.icon} {service.category.name}
                    </span>
                  </div>
                  <h1 className="text-3xl font-bold text-gray-800 mb-2">
                    {service.name}
                  </h1>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      {avgRating} ({service.reviews?.length || 0} đánh giá)
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {service.duration} phút
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-purple-600">
                    {formatPrice(service.price)}
                  </p>
                  <p className="text-sm text-gray-500">/ 1 lần</p>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4">
                <h3 className="font-semibold text-gray-800 mb-2">
                  Mô tả dịch vụ
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
              </div>
            </div>

            {/* Provider Info */}
            <div className="bg-white rounded-2xl shadow-md p-6">
              <h3 className="font-semibold text-gray-800 mb-4">
                Thông tin nhà cung cấp
              </h3>
              <div className="flex items-start gap-4">
                <img
                  src={service.provider.avatar}
                  alt={service.provider.businessName}
                  className="w-16 h-16 rounded-full"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-800 flex items-center gap-2">
                    {service.provider.businessName}
                    <BadgeCheck className="w-5 h-5 text-blue-500" />
                  </h4>
                  <p className="text-sm text-gray-600 mb-2">
                    {service.provider.fullName}
                  </p>
                  {service.provider.description && (
                    <p className="text-sm text-gray-600 mb-3">
                      {service.provider.description}
                    </p>
                  )}
                  {service.provider.businessAddress && (
                    <p className="text-sm text-gray-600 flex items-start gap-2 mb-2">
                      <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      {service.provider.businessAddress}
                    </p>
                  )}
                  <div className="flex gap-2 mt-3">
                    <button 
                      onClick={() => navigate(`/messages/${service.provider.id}`)}
                      className="flex-1 px-4 py-2 border-2 border-purple-600 text-purple-600 rounded-lg hover:bg-purple-50 transition-colors text-sm font-medium flex items-center justify-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4" />
                      Chat với Provider
                    </button>
                    <button className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium">
                      Xem thêm dịch vụ
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Reviews */}
            {service.reviews && service.reviews.length > 0 && (
              <div className="bg-white rounded-2xl shadow-md p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-semibold text-gray-800">
                    Đánh giá ({service.reviews.length})
                  </h3>
                  <div className="flex items-center gap-2 text-2xl font-bold text-purple-600">
                    <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                    {avgRating}
                  </div>
                </div>

                <div className="space-y-4">
                  {displayReviews.map((review) => (
                    <div
                      key={review.id}
                      className="border-b border-gray-200 last:border-0 pb-4 last:pb-0"
                    >
                      <div className="flex items-start gap-3">
                        <img
                          src={review.customer.avatar}
                          alt={review.customer.fullName}
                          className="w-10 h-10 rounded-full"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <h5 className="font-semibold text-gray-800">
                              {review.customer.fullName}
                            </h5>
                            <span className="text-xs text-gray-500">
                              {formatDate(review.createdAt)}
                            </span>
                          </div>
                          <div className="flex items-center gap-1 mb-2">
                            {renderStars(review.rating)}
                          </div>
                          <p className="text-gray-600 text-sm mb-3">
                            {review.comment}
                          </p>

                          {/* Provider Reply */}
                          {review.providerReply && (
                            <div className="bg-purple-50 rounded-lg p-3 ml-4">
                              <div className="flex items-center gap-2 mb-1">
                                <BadgeCheck className="w-4 h-4 text-purple-600" />
                                <span className="text-sm font-medium text-purple-800">
                                  Phản hồi từ {service.provider.businessName}
                                </span>
                              </div>
                              <p className="text-sm text-gray-700">
                                {review.providerReply}
                              </p>
                              <span className="text-xs text-gray-500">
                                {formatDate(review.repliedAt)}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {service.reviews.length > 3 && (
                  <button
                    onClick={() => setShowAllReviews(!showAllReviews)}
                    className="mt-4 text-purple-600 hover:text-purple-700 font-medium text-sm"
                  >
                    {showAllReviews
                      ? "Thu gọn"
                      : `Xem thêm ${service.reviews.length - 3} đánh giá`}
                  </button>
                )}
              </div>
            )}

            {/* Provider Other Services */}
            {providerServices.length > 0 && (
              <div className="bg-white rounded-2xl shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-800">
                    Dịch vụ khác của {service.provider.businessName}
                  </h3>
                  <span className="text-sm text-purple-600">
                    {providerServices.length} dịch vụ
                  </span>
                </div>

                <div className="overflow-x-auto -mx-6 px-6">
                  <div className="flex gap-4 pb-4">
                    {providerServices.map((otherService) => (
                      <div
                        key={otherService.id}
                        onClick={() => navigate(`/service/${otherService.id}`)}
                        className="min-w-[280px] bg-gray-50 rounded-lg overflow-hidden cursor-pointer hover:shadow-lg transition-all group"
                      >
                        {/* Service Image */}
                        <div className="relative h-40 bg-gray-200 overflow-hidden">
                          {otherService.images && otherService.images.length > 0 && (
                            <img
                              src={otherService.images[0].imageUrl}
                              alt={otherService.name}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            />
                          )}
                          <div className="absolute top-2 right-2 bg-purple-600 text-white px-2 py-1 rounded-full text-xs font-semibold">
                            {formatPrice(otherService.price)}
                          </div>
                        </div>

                        {/* Service Info */}
                        <div className="p-4">
                          <h4 className="font-semibold text-gray-900 mb-2 line-clamp-1">
                            {otherService.name}
                          </h4>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                            {otherService.description}
                          </p>
                          
                          <div className="flex items-center justify-between text-sm">
                            <span className="flex items-center gap-1 text-gray-600">
                              <Clock className="w-4 h-4" />
                              {otherService.duration} phút
                            </span>
                            <span className="flex items-center gap-1 text-yellow-500">
                              <Star className="w-4 h-4 fill-yellow-400" />
                              {otherService.reviews?.length > 0
                                ? (otherService.reviews.reduce((acc, r) => acc + r.rating, 0) / otherService.reviews.length).toFixed(1)
                                : "5.0"}
                            </span>
                          </div>

                          <div className="mt-3 flex items-center justify-between">
                            <span className="text-xs text-purple-600 font-medium">
                              {otherService.category.icon} {otherService.category.name}
                            </span>
                            <ArrowRight className="w-4 h-4 text-purple-600 group-hover:translate-x-1 transition-transform" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {loadingProviderServices && (
                  <div className="text-center py-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Column - Booking Card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
              <h3 className="font-semibold text-gray-800 mb-4">
                Đặt lịch ngay
              </h3>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Chọn ngày <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="date"
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      min={new Date().toISOString().split("T")[0]}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Chọn giờ <span className="text-red-500">*</span>
                    {loadingBookedTimes && (
                      <span className="text-xs text-gray-500 ml-2">
                        (Đang kiểm tra...)
                      </span>
                    )}
                  </label>
                  <select
                    value={bookingTime}
                    onChange={(e) => setBookingTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    disabled={!bookingDate || loadingBookedTimes}
                  >
                    <option value="">
                      {!bookingDate ? "Vui lòng chọn ngày trước" : "Chọn giờ"}
                    </option>
                    <option value="09:00" disabled={isTimeSlotBooked("09:00")}>
                      09:00 - 10:00 {isTimeSlotBooked("09:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="10:00" disabled={isTimeSlotBooked("10:00")}>
                      10:00 - 11:00 {isTimeSlotBooked("10:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="11:00" disabled={isTimeSlotBooked("11:00")}>
                      11:00 - 12:00 {isTimeSlotBooked("11:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="14:00" disabled={isTimeSlotBooked("14:00")}>
                      14:00 - 15:00 {isTimeSlotBooked("14:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="15:00" disabled={isTimeSlotBooked("15:00")}>
                      15:00 - 16:00 {isTimeSlotBooked("15:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="16:00" disabled={isTimeSlotBooked("16:00")}>
                      16:00 - 17:00 {isTimeSlotBooked("16:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="17:00" disabled={isTimeSlotBooked("17:00")}>
                      17:00 - 18:00 {isTimeSlotBooked("17:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="18:00" disabled={isTimeSlotBooked("18:00")}>
                      18:00 - 19:00 {isTimeSlotBooked("18:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="19:00" disabled={isTimeSlotBooked("19:00")}>
                      19:00 - 20:00 {isTimeSlotBooked("19:00") ? "(Không khả dụng)" : ""}
                    </option>
                    <option value="20:00" disabled={isTimeSlotBooked("20:00")}>
                      20:00 - 21:00 {isTimeSlotBooked("20:00") ? "(Không khả dụng)" : ""}
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Ghi chú (Tùy chọn)
                  </label>
                  <textarea
                    value={bookingNotes}
                    onChange={(e) => setBookingNotes(e.target.value)}
                    placeholder="Nhập ghi chú cho nhà cung cấp..."
                    rows="3"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4 mb-6">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Giá dịch vụ</span>
                  <span className="font-semibold">
                    {formatPrice(service.price)}
                  </span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Thời gian</span>
                  <span className="font-semibold">{service.duration} phút</span>
                </div>
                <div className="border-t border-gray-200 mt-3 pt-3 flex justify-between">
                  <span className="font-semibold text-gray-800">Tổng cộng</span>
                  <span className="font-bold text-purple-600 text-xl">
                    {formatPrice(service.price)}
                  </span>
                </div>
              </div>

              <button
                onClick={handleBookingSubmit}
                disabled={submitting}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? "Đang đặt lịch..." : "Đặt lịch ngay"}
              </button>

              <p className="text-xs text-gray-500 text-center mt-3">
                Bằng việc đặt lịch, bạn đồng ý với điều khoản sử dụng
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceDetailPage;
