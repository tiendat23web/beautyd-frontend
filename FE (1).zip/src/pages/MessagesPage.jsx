import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { MessageCircle, Send, ArrowLeft, User as UserIcon } from "lucide-react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import {
  getConversations,
  getMessages,
  sendMessage,
  markAllAsRead,
} from "../services/messageService";
import { useAuth } from "../contexts/AuthContext";
import { toast } from "react-toastify";

const MessagesPage = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [messages, setMessages] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);
  const pollingIntervalRef = useRef(null);

  // Fetch conversations on mount
  useEffect(() => {
    fetchConversations();
  }, []);

  // Handle userId from params
  useEffect(() => {
    if (userId) {
      loadChat(parseInt(userId));
    }
  }, [userId]);

  // Poll for new messages when chat is open
  useEffect(() => {
    if (selectedUser) {
      // Poll every 3 seconds
      pollingIntervalRef.current = setInterval(() => {
        fetchMessages(selectedUser.id);
      }, 3000);

      return () => {
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current);
        }
      };
    }
  }, [selectedUser]);

  // Auto scroll to bottom
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchConversations = async () => {
    try {
      const data = await getConversations();
      setConversations(data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      setLoading(false);
    }
  };

  const fetchMessages = async (targetUserId) => {
    try {
      const data = await getMessages(targetUserId);
      setMessages(data);
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const loadChat = async (targetUserId) => {
    try {
      // Find user info from conversations or fetch separately
      let targetUser = conversations.find((c) => c.user.id === targetUserId)?.user;
      
      if (!targetUser) {
        // If not in conversations yet, create a placeholder
        targetUser = { id: targetUserId, fullName: "Provider", avatar: null };
      }

      setSelectedUser(targetUser);
      await fetchMessages(targetUserId);
      await markAllAsRead(targetUserId);
      await fetchConversations(); // Refresh to update unread count
    } catch (error) {
      console.error("Error loading chat:", error);
    }
  };

  const handleSelectConversation = (conversation) => {
    navigate(`/messages/${conversation.user.id}`);
  };

  const handleSendMessage = async () => {
    if (!inputText.trim() || !selectedUser) return;

    try {
      setSending(true);
      await sendMessage(selectedUser.id, inputText.trim());
      setInputText("");
      await fetchMessages(selectedUser.id);
      await fetchConversations();
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Không thể gửi tin nhắn");
    } finally {
      setSending(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (date) => {
    const msgDate = new Date(date);
    const now = new Date();
    const diffMinutes = Math.floor((now - msgDate) / 60000);

    if (diffMinutes < 1) return "Vừa xong";
    if (diffMinutes < 60) return `${diffMinutes} phút trước`;
    if (diffMinutes < 1440)
      return `${Math.floor(diffMinutes / 60)} giờ trước`;
    return msgDate.toLocaleDateString("vi-VN");
  };

  const formatMessageTime = (date) => {
    const msgDate = new Date(date);
    return msgDate.toLocaleTimeString("vi-VN", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!user) {
    navigate("/login");
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto bg-white shadow-lg">
        {/* Conversations List */}
        <div
          className={`${
            selectedUser ? "hidden md:block" : "block"
          } w-full md:w-1/3 border-r border-gray-200`}
        >
          <div className="p-4 border-b border-gray-200 bg-purple-600 text-white">
            <h2 className="text-xl font-bold">Tin nhắn</h2>
          </div>

          <div className="overflow-y-auto" style={{ height: "calc(100vh - 200px)" }}>
            {loading ? (
              <div className="p-4 text-center text-gray-500">Đang tải...</div>
            ) : conversations.length === 0 ? (
              <div className="p-8 text-center">
                <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-700 mb-2">
                  Chưa có tin nhắn
                </h3>
                <p className="text-gray-500 mb-4">
                  Bắt đầu chat với provider khi bạn quan tâm đến dịch vụ
                </p>
                <button
                  onClick={() => navigate("/")}
                  className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors"
                >
                  Khám phá dịch vụ
                </button>
              </div>
            ) : (
              conversations.map((conv) => (
                <div
                  key={conv.user.id}
                  onClick={() => handleSelectConversation(conv)}
                  className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-purple-50 transition-colors ${
                    selectedUser?.id === conv.user.id ? "bg-purple-50" : ""
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="relative">
                      {conv.user.avatar ? (
                        <img
                          src={conv.user.avatar}
                          alt={conv.user.fullName}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                          <UserIcon className="w-6 h-6 text-purple-600" />
                        </div>
                      )}
                      {conv.user.role === "PROVIDER" && (
                        <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white text-xs px-1 rounded">
                          Pro
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-semibold text-gray-900 truncate">
                          {conv.user.fullName}
                        </h4>
                        <span className="text-xs text-gray-500">
                          {formatTime(conv.lastMessage.createdAt)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-600 truncate">
                          {conv.lastMessage.senderId === user.id && "Bạn: "}
                          {conv.lastMessage.content}
                        </p>
                        {conv.unreadCount > 0 && (
                          <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1 ml-2">
                            {conv.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Chat Window */}
        <div className={`${selectedUser ? "block" : "hidden md:block"} w-full md:w-2/3 flex flex-col`}>
          {selectedUser ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-gray-200 bg-white flex items-center gap-3">
                <button
                  onClick={() => navigate("/messages")}
                  className="md:hidden"
                >
                  <ArrowLeft className="w-6 h-6" />
                </button>
                {selectedUser.avatar ? (
                  <img
                    src={selectedUser.avatar}
                    alt={selectedUser.fullName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                    <UserIcon className="w-5 h-5 text-purple-600" />
                  </div>
                )}
                <div>
                  <h3 className="font-semibold text-gray-900">
                    {selectedUser.fullName}
                  </h3>
                  {selectedUser.role === "PROVIDER" && (
                    <span className="text-xs text-gray-500">Provider</span>
                  )}
                </div>
              </div>

              {/* Messages */}
              <div
                className="flex-1 overflow-y-auto p-4 bg-gray-50"
                style={{ height: "calc(100vh - 300px)" }}
              >
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center text-gray-500">
                      <MessageCircle className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                      <p>Bắt đầu cuộc trò chuyện</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((msg) => {
                      const isOwn = msg.senderId === user.id;
                      return (
                        <div
                          key={msg.id}
                          className={`flex ${
                            isOwn ? "justify-end" : "justify-start"
                          }`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md xl:max-w-lg ${
                              isOwn
                                ? "bg-purple-600 text-white"
                                : "bg-white text-gray-900"
                            } rounded-lg px-4 py-2 shadow`}
                          >
                            <p className="break-words">{msg.content}</p>
                            <p
                              className={`text-xs mt-1 ${
                                isOwn ? "text-purple-200" : "text-gray-500"
                              }`}
                            >
                              {formatMessageTime(msg.createdAt)}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="p-4 border-t border-gray-200 bg-white">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Nhập tin nhắn..."
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-purple-500"
                    disabled={sending}
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={!inputText.trim() || sending}
                    className="bg-purple-600 text-white p-3 rounded-full hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-50">
              <div className="text-center text-gray-500">
                <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold mb-2">
                  Chọn một cuộc trò chuyện
                </h3>
                <p>Chọn từ danh sách bên trái để bắt đầu chat</p>
              </div>
            </div>
          )}
        </div>
      </div>

    </div>
  );
};

export default MessagesPage;
