import React, { useState, useEffect } from 'react';
import { Ban, CheckCircle, Search, Filter } from 'lucide-react';
import AdminLayout from '../../layouts/AdminLayout';
import { getAllUsers, banUser, unbanUser } from '../../services/adminService';
import { toast } from 'react-toastify';
import ConfirmModal from '../../components/ConfirmModal';

const AdminUsersPage = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [modalAction, setModalAction] = useState(null); // 'ban' or 'unban'
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, [page, roleFilter, statusFilter]);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const data = await getAllUsers(page, 20, roleFilter, statusFilter);
      setUsers(data.users);
      setTotalPages(data.totalPages);
    } catch (error) {
      console.error('Fetch users error:', error);
      toast.error('Không thể tải danh sách user');
    } finally {
      setLoading(false);
    }
  };

  const openBanModal = (user) => {
    setSelectedUser(user);
    setModalAction('ban');
    setShowConfirmModal(true);
  };

  const openUnbanModal = (user) => {
    setSelectedUser(user);
    setModalAction('unban');
    setShowConfirmModal(true);
  };

  const handleConfirmAction = async () => {
    if (!selectedUser || !modalAction) return;

    try {
      if (modalAction === 'ban') {
        await banUser(selectedUser.id);
        toast.success('Đã khóa tài khoản');
      } else {
        await unbanUser(selectedUser.id);
        toast.success('Đã mở khóa tài khoản');
      }
      setShowConfirmModal(false);
      setSelectedUser(null);
      setModalAction(null);
      fetchUsers();
    } catch (error) {
      toast.error(error.error || 'Lỗi khi thực hiện thao tác');
    }
  };

  const filteredUsers = users.filter(user => 
    user.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRoleBadge = (role) => {
    const colors = {
      USER: 'bg-blue-100 text-blue-700',
      PROVIDER: 'bg-purple-100 text-purple-700',
      ADMIN: 'bg-red-100 text-red-700'
    };
    return colors[role] || 'bg-gray-100 text-gray-700';
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Quản lý User</h1>
          <p className="text-gray-600">Xem và quản lý tài khoản người dùng</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Tìm theo tên hoặc email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>

            {/* Role Filter */}
            <select
              value={roleFilter}
              onChange={(e) => {
                setRoleFilter(e.target.value);
                setPage(1);
              }}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"
            >
              <option value="ALL">Tất cả vai trò</option>
              <option value="USER">User</option>
              <option value="PROVIDER">Provider</option>
              <option value="ADMIN">Admin</option>
            </select>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"
            >
              <option value="ALL">Tất cả trạng thái</option>
              <option value="ACTIVE">Active</option>
              <option value="BANNED">Banned</option>
            </select>
          </div>
        </div>

        {/* Users Table */}
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Họ tên</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vai trò</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trạng thái</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Bookings</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{user.id}</td>
                      <td className="px-6 py-4">
                        <div>
                          <p className="text-sm font-medium text-gray-900">{user.fullName}</p>
                          {user.businessName && (
                            <p className="text-xs text-gray-500">{user.businessName}</p>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{user.email}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs font-medium rounded ${getRoleBadge(user.role)}`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {user.isActive ? (
                          <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded">
                            Active
                          </span>
                        ) : (
                          <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-medium rounded">
                            Banned
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {user._count?.bookings || 0}
                      </td>
                      <td className="px-6 py-4">
                        {user.role !== 'ADMIN' && (
                          <div className="flex gap-2">
                            {user.isActive ? (
                              <button
                                onClick={() => openBanModal(user)}
                                className="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700 transition-colors flex items-center gap-1"
                              >
                                <Ban className="w-3 h-3" />
                                Ban
                              </button>
                            ) : (
                              <button
                                onClick={() => openUnbanModal(user)}
                                className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700 transition-colors flex items-center gap-1"
                              >
                                <CheckCircle className="w-3 h-3" />
                                Unban
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="border-t border-gray-200 px-6 py-4 flex items-center justify-between">
                <p className="text-sm text-gray-600">
                  Page {page} of {totalPages}
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                    className="px-4 py-2 border border-gray-300 rounded-lg disabled:opacity-50 hover:bg-gray-50"
                  >
                    Previous
                  </button>
                  <button
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                    className="px-4 py-2 border border-gray-300 rounded-lg disabled:opacity-50 hover:bg-gray-50"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Ban/Unban Confirmation Modal */}
        <ConfirmModal
          isOpen={showConfirmModal}
          onClose={() => {
            setShowConfirmModal(false);
            setSelectedUser(null);
            setModalAction(null);
          }}
          onConfirm={handleConfirmAction}
          title={modalAction === 'ban' ? 'Khóa tài khoản' : 'Mở khóa tài khoản'}
          message={
            selectedUser
              ? modalAction === 'ban'
                ? `Xác nhận khóa tài khoản "${selectedUser.fullName}"?`
                : `Xác nhận mở khóa tài khoản "${selectedUser.fullName}"?`
              : ''
          }
          confirmText={modalAction === 'ban' ? 'Khóa' : 'Mở khóa'}
          cancelText="Hủy"
          confirmColor={modalAction === 'ban' ? 'red' : 'green'}
          type={modalAction === 'ban' ? 'warning' : 'success'}
        />
      </div>
    </AdminLayout>
  );
};

export default AdminUsersPage;
