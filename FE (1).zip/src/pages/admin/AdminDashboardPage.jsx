import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, DollarSign, ClipboardList, FileCheck, TrendingUp } from 'lucide-react';
import AdminLayout from '../../layouts/AdminLayout';
import { getDashboardStats } from '../../services/adminService';
import { toast } from 'react-toastify';

const AdminDashboardPage = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalProviders: 0,
    totalBookings: 0,
    revenue: 0,
    pendingKYC: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const data = await getDashboardStats();
      setStats(data);
    } catch (error) {
      console.error('Fetch stats error:', error);
      toast.error('Không thể tải thống kê');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };

  const statCards = [
    {
      title: 'Tổng User',
      value: stats.totalUsers,
      icon: Users,
      color: 'blue',
      onClick: () => navigate('/admin/users?role=USER')
    },
    {
      title: 'Tổng Provider',
      value: stats.totalProviders,
      icon: TrendingUp,
      color: 'purple',
      onClick: () => navigate('/admin/users?role=PROVIDER')
    },
    {
      title: 'Tổng Bookings',
      value: stats.totalBookings,
      icon: ClipboardList,
      color: 'green',
      onClick: () => {}
    },
    {
      title: 'Tổng Doanh Thu',
      value: formatPrice(stats.revenue),
      icon: DollarSign,
      color: 'orange',
      onClick: () => {}
    },
    {
      title: 'KYC Chờ Duyệt',
      value: stats.pendingKYC,
      icon: FileCheck,
      color: 'red',
      onClick: () => navigate('/admin/kyc')
    }
  ];

  const colorClasses = {
    blue: 'from-blue-500 to-cyan-500',
    purple: 'from-purple-500 to-pink-500',
    green: 'from-green-500 to-emerald-500',
    orange: 'from-orange-500 to-amber-500',
    red: 'from-red-500 to-rose-500'
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Tổng quan hệ thống</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {statCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.title}
                onClick={card.onClick}
                className="bg-white rounded-xl border border-gray-200 p-6 cursor-pointer hover:shadow-lg transition-all"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${colorClasses[card.color]} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">{card.title}</h3>
                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button
            onClick={() => navigate('/admin/kyc')}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all text-left"
          >
            <FileCheck className="w-10 h-10 text-red-600 mb-3" />
            <h3 className="font-semibold text-gray-900 mb-1">Duyệt KYC</h3>
            <p className="text-sm text-gray-600">Xem và duyệt KYC provider</p>
            {stats.pendingKYC > 0 && (
              <span className="inline-block mt-2 px-3 py-1 bg-red-100 text-red-700 text-sm font-medium rounded-full">
                {stats.pendingKYC} chờ duyệt
              </span>
            )}
          </button>

          <button
            onClick={() => navigate('/admin/users')}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all text-left"
          >
            <Users className="w-10 h-10 text-blue-600 mb-3" />
            <h3 className="font-semibold text-gray-900 mb-1">Quản lý User</h3>
            <p className="text-sm text-gray-600">Xem, khóa/mở khóa tài khoản</p>
          </button>

          <div className="bg-white border border-gray-200 rounded-xl p-6 text-left">
            <ClipboardList className="w-10 h-10 text-green-600 mb-3" />
            <h3 className="font-semibold text-gray-900 mb-1">Thống kê</h3>
            <p className="text-sm text-gray-600">Xem báo cáo chi tiết</p>
            <span className="inline-block mt-2 px-3 py-1 bg-gray-100 text-gray-600 text-sm font-medium rounded-full">
              Coming soon
            </span>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboardPage;
