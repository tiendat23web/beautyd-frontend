import React, { useState, useEffect } from 'react';
import { X, Check, FileText, Image as ImageIcon } from 'lucide-react';
import AdminLayout from '../../layouts/AdminLayout';
import { getPendingKYC, approveKYC, rejectKYC } from '../../services/adminService';
import { toast } from 'react-toastify';
import ConfirmModal from '../../components/ConfirmModal';

const AdminKYCPage = () => {
  const [documents, setDocuments] = useState([]);
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [selectedDoc, setSelectedDoc] = useState(null);

  useEffect(() => {
    fetchPendingKYC();
  }, []);

  const fetchPendingKYC = async () => {
    try {
      const data = await getPendingKYC();
      // Group by user
      const grouped = {};
      data.documents.forEach(doc => {
        if (!grouped[doc.userId]) {
          grouped[doc.userId] = {
            user: doc.user,
            documents: []
          };
        }
        grouped[doc.userId].documents.push(doc);
      });
      setDocuments(Object.values(grouped));
    } catch (error) {
      console.error('Fetch KYC error:', error);
      toast.error('Không thể tải danh sách KYC');
    } finally {
      setLoading(false);
    }
  };

  const openApproveModal = (doc) => {
    setSelectedDoc(doc);
    setShowApproveModal(true);
  };

  const handleApprove = async () => {
    if (!selectedDoc) return;
    
    try {
      await approveKYC(selectedDoc.id);
      toast.success('Đã duyệt tài liệu');
      setShowApproveModal(false);
      setSelectedDoc(null);
      fetchPendingKYC();
    } catch (error) {
      toast.error('Lỗi khi duyệt tài liệu');
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast.error('Vui lòng nhập lý do từ chối');
      return;
    }

    try {
      await rejectKYC(selectedDoc.id, rejectReason);
      toast.success('Đã từ chối tài liệu');
      setShowRejectModal(false);
      setRejectReason('');
      setSelectedDoc(null);
      fetchPendingKYC();
    } catch (error) {
      toast.error('Lỗi khi từ chối tài liệu');
    }
  };

  const openRejectModal = (doc) => {
    setSelectedDoc(doc);
    setShowRejectModal(true);
  };

  const getDocTypeLabel = (type) => {
    const labels = {
      'CITIZEN_ID_FRONT': 'CCCD Mặt trước',
      'CITIZEN_ID_BACK': 'CCCD Mặt sau',
      'BUSINESS_LICENSE': 'Giấy phép KD'
    };
    return labels[type] || type;
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Duyệt KYC</h1>
          <p className="text-gray-600">{documents.length} provider chờ duyệt</p>
        </div>

        {documents.length === 0 ? (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">Không có KYC chờ duyệt</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Provider List */}
            <div className="lg:col-span-1 space-y-3">
              {documents.map((item) => (
                <div
                  key={item.user.id}
                  onClick={() => setSelectedProvider(item)}
                  className={`bg-white p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedProvider?.user.id === item.user.id
                      ? 'border-red-500 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <h3 className="font-semibold text-gray-900">{item.user.fullName}</h3>
                  <p className="text-sm text-gray-600">{item.user.businessName}</p>
                  <span className="inline-block mt-2 px-2 py-1 bg-orange-100 text-orange-700 text-xs rounded">
                    {item.documents.length} tài liệu
                  </span>
                </div>
              ))}
            </div>

            {/* Provider Details */}
            <div className="lg:col-span-2">
              {selectedProvider ? (
                <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-6">
                  {/* Provider Info */}
                  <div className="border-b pb-4">
                    <h2 className="text-xl font-bold text-gray-900 mb-2">{selectedProvider.user.fullName}</h2>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <p><span className="font-medium">Email:</span> {selectedProvider.user.email}</p>
                      <p><span className="font-medium">Business:</span> {selectedProvider.user.businessName}</p>
                      <p className="col-span-2"><span className="font-medium">Địa chỉ:</span> {selectedProvider.user.businessAddress}</p>
                    </div>
                  </div>

                  {/* Documents */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-gray-900">Tài liệu KYC</h3>
                    {selectedProvider.documents.map((doc) => (
                      <div key={doc.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-medium text-gray-900">{getDocTypeLabel(doc.type)}</h4>
                            <p className="text-sm text-gray-500">{new Date(doc.createdAt).toLocaleDateString('vi-VN')}</p>
                          </div>
                          <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded">
                            Pending
                          </span>
                        </div>

                        {/* Image */}
                        <img
                          src={doc.fileUrl}
                          alt={doc.type}
                          className="w-full h-64 object-contain bg-gray-50 rounded-lg mb-3"
                        />

                        {/* Actions */}
                        <div className="flex gap-2">
                          <button
                            onClick={() => openApproveModal(doc)}
                            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                          >
                            <Check className="w-4 h-4" />
                            Duyệt
                          </button>
                          <button
                            onClick={() => openRejectModal(doc)}
                            className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
                          >
                            <X className="w-4 h-4" />
                            Từ chối
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                  <ImageIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Chọn provider để xem chi tiết</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Approve Modal */}
        <ConfirmModal
          isOpen={showApproveModal}
          onClose={() => {
            setShowApproveModal(false);
            setSelectedDoc(null);
          }}
          onConfirm={handleApprove}
          title="Duyệt tài liệu KYC"
          message={selectedDoc ? `Xác nhận duyệt tài liệu "${getDocTypeLabel(selectedDoc.type)}"?` : ''}
          confirmText="Duyệt"
          cancelText="Hủy"
          confirmColor="green"
          type="success"
        />

        {/* Reject Modal */}
        {showRejectModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl p-6 max-w-md w-full">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Từ chối tài liệu</h3>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Nhập lý do từ chối..."
                rows="4"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
              <div className="flex gap-3 mt-4">
                <button
                  onClick={() => {
                    setShowRejectModal(false);
                    setRejectReason('');
                    setSelectedDoc(null);
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Hủy
                </button>
                <button
                  onClick={handleReject}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Xác nhận từ chối
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};

export default AdminKYCPage;
