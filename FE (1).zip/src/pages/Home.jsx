import React, { useState, useEffect } from "react";
import { ChevronRight, Star, Clock, Heart, Gift, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { getCategory, getServices } from "../services/servicesService";
import { addFavorite, removeFavorite } from "../services/favoritesService";
import { useAuth } from "../contexts/AuthContext";
import { toast } from "react-toastify";

// Service Card Component
const ServiceCard = ({ service, userFavorites = [], onFavoriteChange }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteLoading, setFavoriteLoading] = useState(false);

  useEffect(() => {
    setIsFavorite(userFavorites.includes(service.id));
  }, [userFavorites, service.id]);
  
  const formatPrice = (price) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(price);
  };

  const handleFavoriteClick = async (e) => {
    e.stopPropagation();
    
    if (!user) {
      toast.error('Vui lòng đăng nhập để thêm yêu thích');
      navigate('/login');
      return;
    }

    if (favoriteLoading) return;

    try {
      setFavoriteLoading(true);
      
      if (isFavorite) {
        await removeFavorite(service.id);
        setIsFavorite(false);
        toast.success('Đã xóa khỏi yêu thích');
      } else {
        await addFavorite(service.id);
        setIsFavorite(true);
        toast.success('Đã thêm vào yêu thích');
      }
      
      if (onFavoriteChange) {
        onFavoriteChange();
      }
    } catch (error) {
      console.error('Favorite error:', error);
      toast.error('Có lỗi xảy ra');
    } finally {
      setFavoriteLoading(false);
    }
  };

  return (
    <div 
      onClick={() => navigate(`/service/${service.id}`)}
      className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 group cursor-pointer"
    >
      <div className="relative overflow-hidden h-48">
        <img
          src={service.images[0]?.imageUrl}
          alt={service.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md hover:bg-purple-50 cursor-pointer z-10"
          onClick={handleFavoriteClick}
        >
          <Heart className={`w-5 h-5 transition-colors ${
            isFavorite ? 'text-red-500 fill-red-500' : 'text-gray-400 hover:text-red-500'
          }`} />
        </div>
        <div className="absolute bottom-2 left-2 bg-purple-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
          HOT
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-gray-800 line-clamp-2 flex-1">
            {service.name}
          </h3>
        </div>
        <p className="text-sm text-gray-600 line-clamp-2 mb-3">
          {service.description}
        </p>
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
          <Clock className="w-4 h-4" />
          <span>{service.duration} phút</span>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xl font-bold text-purple-600">
              {formatPrice(service.price)}
            </span>
          </div>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/service/${service.id}`);
            }}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
          >
            Đặt lịch
          </button>
        </div>
        <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img
              src={service.provider.avatar}
              alt={service.provider.fullName}
              className="w-6 h-6 rounded-full"
            />
            <span className="text-xs text-gray-600">
              {service.provider.businessName}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-xs text-gray-600">4.8</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// Category Card Component
const CategoryCard = ({ category }) => {
  const navigate = useNavigate();
  
  return (
    <div 
      onClick={() => navigate(`/services?categoryId=${category.id}`)}
      className="bg-white rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-100 hover:border-purple-200"
    >
      <div className="text-4xl mb-2">{category.icon}</div>
      <h3 className="font-semibold text-gray-800 mb-1">{category.name}</h3>
      <p className="text-xs text-gray-500 line-clamp-2">
        {category.description}
      </p>
      <div className="mt-3 text-sm text-purple-600 font-medium flex items-center gap-1">
        {category._count.services} dịch vụ
        <ChevronRight className="w-4 h-4" />
      </div>
    </div>
  );
};

// Main Home Component
const HomePage = () => {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userFavorites, setUserFavorites] = useState([]);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const { user } = useAuth();

  // Banner data - dynamically using first 3 services from database
  const gradients = [
    "from-purple-600 via-pink-500 to-red-500",
    "from-blue-600 via-indigo-500 to-purple-500",
    "from-pink-600 via-rose-500 to-red-500",
  ];

  const banners = services.slice(0, 3).map((service, index) => ({
    title: service.name,
    highlight: service.category?.name || "DỊCH VỤ HOT",
    discount: new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(service.price).replace("₫", "").trim(),
    description: service.description,
    image: service.images[0]?.imageUrl || "https://images.unsplash.com/photo-1560750588-73207b1ef5b8",
    gradient: gradients[index] || gradients[0],
    serviceId: service.id,
  }));

  // Auto scroll banner - only run when we have banners
  useEffect(() => {
    if (banners.length === 0) return;
    
    const timer = setInterval(() => {
      setCurrentBannerIndex((prev) => (prev + 1) % banners.length);
    }, 3000); // Change banner every 5 seconds

    return () => clearInterval(timer);
  }, [banners.length]);

  // Fetch data từ API
  useEffect(() => {
    fetchData();
  }, [user]);

  const fetchData = async () => {
    try {
      const responseCategories = await getCategory();
      const responseServices = await getServices();
      
      if (responseCategories.status === 200) {
        setCategories(responseCategories.data);
      }
      if (responseServices.status === 200) {
        setServices(responseServices.data);
      }

      // Fetch favorites if user is logged in
      if (user) {
        try {
          const { getFavorites } = await import('../services/favoritesService');
          const favoritesData = await getFavorites();
          setUserFavorites(favoritesData.map(fav => fav.serviceId));
        } catch (error) {
          console.error('Error fetching favorites:', error);
        }
      }

      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  const currentBanner = banners[currentBannerIndex] || banners[0];

  const goToBanner = (index) => {
    setCurrentBannerIndex(index);
  };

  const nextBanner = () => {
    setCurrentBannerIndex((prev) => (prev + 1) % banners.length);
  };

  const prevBanner = () => {
    setCurrentBannerIndex((prev) => (prev - 1 + banners.length) % banners.length);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Uncomment when using separate files */}
      <Header />
      {/* Hero Banner Carousel */}
      {loading || banners.length === 0 ? (
        // Loading skeleton for banner
        <section className="bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 text-white">
          <div className="max-w-7xl mx-auto px-4 py-16">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="h-12 bg-white/20 rounded mb-4 animate-pulse"></div>
                <div className="h-8 bg-white/20 rounded mb-6 animate-pulse"></div>
                <div className="flex flex-wrap gap-4">
                  <div className="h-12 w-40 bg-white/30 rounded-full animate-pulse"></div>
                  <div className="h-12 w-40 bg-white/30 rounded-full animate-pulse"></div>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="h-64 bg-white/20 rounded-2xl animate-pulse"></div>
              </div>
            </div>
          </div>
        </section>
      ) : (
        <section className={`bg-gradient-to-r ${currentBanner.gradient} text-white relative transition-all duration-500`}>
          <div className="max-w-7xl mx-auto px-4 py-16">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-4">
                  {currentBanner.title}
                  <br />
                  <span className="text-yellow-300">{currentBanner.highlight}</span>
                </h1>
                <p className="text-xl mb-6">
                  Giảm ngay{" "}
                  <span className="font-bold text-yellow-300">{currentBanner.discount}</span>
                  <br />
                  <span className="text-sm">
                    {currentBanner.description}
                  </span>
                </p>
                <div className="flex flex-wrap gap-4">
                  <button 
                    onClick={() => currentBanner.serviceId && navigate(`/service/${currentBanner.serviceId}`)}
                    className="bg-white text-purple-600 px-8 py-3 rounded-full font-bold hover:bg-gray-100 transition-colors shadow-lg"
                  >
                    Đặt lịch ngay
                  </button>
                  <button 
                    onClick={() => currentBanner.serviceId && navigate(`/service/${currentBanner.serviceId}`)}
                    className="border-2 border-white text-white px-8 py-3 rounded-full font-bold hover:bg-white hover:text-purple-600 transition-colors"
                  >
                    Xem chi tiết
                  </button>
                </div>
              </div>
              <div className="hidden md:block">
                <img
                  src={currentBanner.image}
                  alt={currentBanner.title}
                  className="rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
          
          {/* Navigation Arrows */}
          <button 
            onClick={prevBanner}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full backdrop-blur-sm transition-all"
            aria-label="Previous banner"
          >
            <ChevronRight className="w-6 h-6 rotate-180" />
          </button>
          <button 
            onClick={nextBanner}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full backdrop-blur-sm transition-all"
            aria-label="Next banner"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Dots Navigation */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
            {banners.map((_, index) => (
              <button
                key={index}
                onClick={() => goToBanner(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentBannerIndex 
                    ? 'bg-white w-8' 
                    : 'bg-white/50 hover:bg-white/75'
                }`}
                aria-label={`Go to banner ${index + 1}`}
              />
            ))}
          </div>
        </section>
      )}

      {/* Quick Actions */}
      <section className="max-w-7xl mx-auto px-4 -mt-8 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            {
              icon: <Gift className="w-8 h-8" />,
              label: "Ưu đãi",
              color: "bg-orange-500",
            },
            {
              icon: <MapPin className="w-8 h-8" />,
              label: "Gần tôi",
              color: "bg-blue-500",
            },
            {
              icon: <Star className="w-8 h-8" />,
              label: "Đối tác",
              color: "bg-green-500",
            },
            {
              icon: <Heart className="w-8 h-8" />,
              label: "Rewards",
              color: "bg-pink-500",
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow cursor-pointer text-center"
            >
              <div
                className={`${item.color} w-16 h-16 rounded-full flex items-center justify-center text-white mx-auto mb-2`}
              >
                {item.icon}
              </div>
              <span className="text-sm font-medium text-gray-700">
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Danh mục dịch vụ</h2>
          <a
            href="#"
            className="text-purple-600 font-medium flex items-center gap-1 hover:gap-2 transition-all"
          >
            Xem tất cả
            <ChevronRight className="w-5 h-5" />
          </a>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="bg-gray-200 rounded-lg h-40 animate-pulse"
              ></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        )}
      </section>

      {/* Hot Services Section */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">
              Khuyến mãi HOT 🔥
            </h2>
            <p className="text-gray-600 text-sm mt-1">
              Ưu đãi độc quyền chỉ có tại BeautyX
            </p>
          </div>
          <a
            href="#"
            className="text-purple-600 font-medium flex items-center gap-1 hover:gap-2 transition-all"
          >
            Xem thêm
            <ChevronRight className="w-5 h-5" />
          </a>
        </div>
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="bg-gray-200 rounded-lg h-96 animate-pulse"
              ></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {services.map((service) => (
              <ServiceCard 
                key={service.id} 
                service={service} 
                userFavorites={userFavorites}
                onFavoriteChange={fetchData}
              />
            ))}
          </div>
        )}
      </section>

      {/* Features Section */}
      <section className="bg-purple-50 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-800 text-center mb-8">
            Vì sao nên chọn BeautyX?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                icon: "🎯",
                title: "Đặt lịch dễ dàng",
                desc: "Đặt lịch nhanh chóng chỉ với vài thao tác đơn giản",
              },
              {
                icon: "💎",
                title: "Đối tác uy tín",
                desc: "Hơn 1000+ spa & salon chất lượng cao trên toàn quốc",
              },
              {
                icon: "🎁",
                title: "Ưu đãi hấp dẫn",
                desc: "Giảm giá lên đến 50% cho khách hàng thân thiết",
              },
              {
                icon: "🌟",
                title: "Dịch vụ đa dạng",
                desc: "Từ chăm sóc da, massage đến nail với nhiều lựa chọn",
              },
            ].map((feature, idx) => (
              <div
                key={idx}
                className="bg-white rounded-lg p-6 text-center shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="text-5xl mb-3">{feature.icon}</div>
                <h3 className="font-bold text-gray-800 mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-8 md:p-12 text-white text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Trở thành đối tác BeautyX ngay hôm nay!
          </h2>
          <p className="text-lg mb-8 text-purple-100 max-w-2xl mx-auto">
            Tiếp cận hàng triệu khách hàng tiềm năng và phát triển doanh nghiệp
            của bạn cùng BeautyX
          </p>
          <button 
            onClick={() => navigate('/register')}
            className="bg-white text-purple-600 px-8 py-3 rounded-full font-bold hover:bg-gray-100 transition-colors shadow-lg"
          >
            Đăng ký ngay
          </button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HomePage;
