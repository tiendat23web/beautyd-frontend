import React, { useState, useEffect } from 'react';
import { Star as StarIcon, Filter } from 'lucide-react';
import ProviderLayout from '../../layouts/ProviderLayout';
import ReviewCard from '../../components/ReviewCard';
import { getProviderReviews, replyToReview, reportReview } from '../../services/providerService';

const ProviderReviewsPage = () => {
  const [reviews, setReviews] = useState([]);
  const [filteredReviews, setFilteredReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterRating, setFilterRating] = useState('all');
  
  useEffect(() => {
    fetchReviews();
  }, []);

  useEffect(() => {
    filterReviewsByRating();
  }, [reviews, filterRating]);

  const fetchReviews = async () => {
    try {
      const response = await getProviderReviews();
      if (response.status === 200) {
        setReviews(response.data || generateMockReviews());
      } else {
        setReviews(generateMockReviews());
      }
    } catch (error) {
      console.error('Fetch reviews error:', error);
      setReviews(generateMockReviews());
    } finally {
      setLoading(false);
    }
  };

  const generateMockReviews = () => [
    {
      id: 1,
      customer: { fullName: 'Nguyễn Văn A' },
      service: { name: 'Cắt tóc nam' },
      rating: 5,
      content: 'Dịch vụ rất tốt, tôi rất hài lòng!',
      createdAt: new Date().toISOString(),
      providerReply: null
    },
    {
      id: 2,
      customer: { fullName: 'Trần Thị B' },
      service: { name: 'Nhuộm tóc' },
      rating: 4,
      content: 'Khá ổn, giá cả hợp lý',
      createdAt: new Date().toISOString(),
      providerReply: 'Cảm ơn bạn đã sử dụng dịch vụ!'
    }
  ];

  const filterReviewsByRating = () => {
    if (filterRating === 'all') {
      setFilteredReviews(reviews);
    } else {
      setFilteredReviews(reviews.filter(r => r.rating === parseInt(filterRating)));
    }
  };

  const handleReply = async (reviewId, reply) => {
    await replyToReview(reviewId, reply);
    fetchReviews();
  };

  const handleReport = async (reviewId, reason) => {
    await reportReview(reviewId, reason);
  };

  const calculateAverageRating = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  const getRatingDistribution = () => {
    const dist = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    reviews.forEach(review => {
      dist[review.rating]++;
    });
    return dist;
  };

  const ratingDist = getRatingDistribution();

  if (loading) {
    return (
      <ProviderLayout>
        <div className="flex items-center justify-center h-64">
          <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </ProviderLayout>
    );
  }

  return (
    <ProviderLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Quản lý Đánh giá</h1>
          <p className="text-gray-600">Xem và phản hồi đánh giá từ khách hàng</p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-purple-500 to-pink-500 text-white rounded-xl p-6">
            <p className="text-purple-100 mb-2">Đánh giá trung bình</p>
            <div className="flex items-center gap-2">
              <span className="text-4xl font-bold">{calculateAverageRating()}</span>
              <StarIcon className="w-8 h-8 fill-yellow-300 text-yellow-300" />
            </div>
            <p className="text-sm text-purple-100 mt-2">Từ {reviews.length} đánh giá</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 md:col-span-2">
            <h3 className="font-semibold text-gray-900 mb-4">Phân bố đánh giá</h3>
            <div className="space-y-2">
              {[5, 4, 3, 2, 1].map((star) => (
                <div key={star} className="flex items-center gap-3">
                  <div className="flex items-center gap-1 w-16">
                    <span className="text-sm font-medium">{star}</span>
                    <StarIcon className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  </div>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-purple-600 h-2 rounded-full"
                      style={{
                        width: `${reviews.length > 0 ? (ratingDist[star] / reviews.length) * 100 : 0}%`
                      }}
                    />
                  </div>
                  <span className="text-sm text-gray-600 w-12 text-right">{ratingDist[star]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Filter */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center gap-4">
            <Filter className="w-5 h-5 text-gray-600" />
            <span className="font-medium text-gray-700">Lọc theo:</span>
            <select
              value={filterRating}
              onChange={(e) => setFilterRating(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="all">Tất cả đánh giá</option>
              <option value="5">5 sao</option>
              <option value="4">4 sao</option>
              <option value="3">3 sao</option>
              <option value="2">2 sao</option>
              <option value="1">1 sao</option>
            </select>
          </div>
        </div>

        {/* Reviews List */}
        <div className="space-y-4">
          {filteredReviews.length > 0 ? (
            filteredReviews.map((review) => (
              <ReviewCard
                key={review.id}
                review={review}
                onReply={handleReply}
                onReport={handleReport}
              />
            ))
          ) : (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
              <StarIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 font-medium mb-2">Chưa có đánh giá nào</p>
              <p className="text-gray-500 text-sm">
                Đánh giá từ khách hàng sẽ hiển thị tại đây
              </p>
            </div>
          )}
        </div>
      </div>
    </ProviderLayout>
  );
};

export default ProviderReviewsPage;
