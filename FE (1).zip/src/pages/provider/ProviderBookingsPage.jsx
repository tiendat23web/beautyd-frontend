import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { ClipboardList, X, CheckCircle, XCircle, Play, CheckCheck } from "lucide-react";
import ProviderLayout from "../../layouts/ProviderLayout";
import {
  getProviderBookings,
  acceptBooking,
  rejectBooking,
  updateBookingStatus,
} from "../../services/providerService";

const ProviderBookingsPage = () => {
  const navigate = useNavigate();
  const [bookings, setBookings] = useState({
    pending: [],
    approved: [],
    in_service: [],
    completed: [],
    cancelled: [],
  });
  const [rejectModal, setRejectModal] = useState({
    open: false,
    booking: null,
  });
  const [rejectReason, setRejectReason] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await getProviderBookings();
      console.log(response.data);

      if (response.status === 200) {
        const data = response.data || generateMockBookings();
        organizeBookings(data);
      } else {
        organizeBookings(generateMockBookings());
      }
    } catch (error) {
      console.error("Fetch bookings error:", error);
      organizeBookings(generateMockBookings());
    } finally {
      setLoading(false);
    }
  };

  const organizeBookings = (data) => {
    const organized = {
      pending: data.filter((b) => b.status === "PENDING"),
      approved: data.filter((b) => b.status === "CONFIRMED"),
      in_service: data.filter((b) => b.status === "CHECKED_IN"),
      completed: data.filter((b) => b.status === "COMPLETED"),
      cancelled: data.filter((b) => b.status === "REJECTED" || b.status === "CANCELLED"),
    };
    setBookings(organized);
  };

  const generateMockBookings = () => {
    return [
      {
        id: 1,
        customer: { fullName: "Nguyễn Văn A", email: "a@example.com" },
        service: { name: "Cắt tóc nam" },
        bookingTime: new Date().toISOString(),
        status: "pending",
      },
    ];
  };

  const handleAccept = async (booking) => {
    try {
      const response = await acceptBooking(booking.id);
      if (response.status === 200) {
        toast.success("Đã nhận đơn hàng");
        fetchBookings();
      } else {
        toast.error("Có lỗi xảy ra");
      }
    } catch (error) {
      console.error("Accept booking error:", error);
      toast.error("Có lỗi xảy ra");
    }
  };

  const handleRejectClick = (booking) => {
    setRejectModal({ open: true, booking });
  };

  const handleRejectConfirm = async () => {
    if (!rejectReason.trim()) {
      toast.error("Vui lòng nhập lý do từ chối");
      return;
    }

    try {
      const response = await rejectBooking(
        rejectModal.booking.id,
        rejectReason,
      );
      if (response.status === 200) {
        toast.success("Đã từ chối đơn hàng");
        fetchBookings();
        setRejectModal({ open: false, booking: null });
        setRejectReason("");
      } else {
        toast.error("Có lỗi xảy ra");
      }
    } catch (error) {
      console.error("Reject booking error:", error);
      toast.error("Có lỗi xảy ra");
    }
  };

  const handleStartService = async (booking) => {
    try {
      const response = await updateBookingStatus(booking.id, "CHECKED_IN");
      if (response.status === 200) {
        toast.success("Đã bắt đầu phục vụ");
        fetchBookings();
      } else {
        toast.error("Có lỗi xảy ra");
      }
    } catch (error) {
      console.error("Start service error:", error);
      toast.error("Có lỗi xảy ra");
    }
  };

  const handleCompleteService = async (booking) => {
    try {
      const response = await updateBookingStatus(booking.id, "COMPLETED");
      if (response.status === 200) {
        toast.success("Đã hoàn tất dịch vụ");
        fetchBookings();
      } else {
        toast.error("Có lỗi xảy ra");
      }
    } catch (error) {
      console.error("Complete service error:", error);
      toast.error("Có lỗi xảy ra");
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const BookingCard = ({ booking, status }) => {
    return (
      <div
        onClick={() => navigate(`/provider/booking/${booking.id}`)}
        className="bg-white border-2 border-gray-200 rounded-lg p-4 transition-all cursor-pointer hover:shadow-lg hover:border-purple-300"
      >
        {/* Header với tên và avatar */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h4 className="font-semibold text-gray-900 mb-1">
              {booking.user?.fullName || "Khách hàng"}
            </h4>
            <p className="text-sm text-gray-600">{booking.service?.name}</p>
            <p className="text-sm text-purple-600 font-semibold mt-1">
              {booking.totalPrice?.toLocaleString("vi-VN")}đ
            </p>
          </div>
          {booking.user?.avatar && (
            <img
              src={booking.user.avatar}
              alt={booking.user.fullName}
              className="w-12 h-12 rounded-full object-cover ml-3"
            />
          )}
        </div>

        {/* Thời gian */}
        <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
          <span>📅</span>
          <span>{formatDate(booking.bookingDate)}</span>
        </div>

        {/* Thời lượng */}
        <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
          <span>⏱️</span>
          <span>{booking.service?.duration} phút</span>
        </div>

        {/* Notes */}
        {booking.notes && (
          <div className="text-xs text-gray-600 bg-gray-50 rounded p-2 mb-3 flex items-start gap-2">
            <span>💬</span>
            <span className="flex-1">{booking.notes}</span>
          </div>
        )}

        {/* Số điện thoại */}
        {booking.user?.phone && (
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
            <span>📞</span>
            <span>{booking.user.phone}</span>
          </div>
        )}

        {/* Action buttons - ngăn event bubbling */}
        <div onClick={(e) => e.stopPropagation()}>
          {status === "pending" && (
            <div className="flex gap-2">
              <button
                onClick={() => handleAccept(booking)}
                className="flex-1 flex items-center justify-center gap-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
              >
                <CheckCircle className="w-4 h-4" />
                Nhận
              </button>
              <button
                onClick={() => handleRejectClick(booking)}
                className="flex-1 flex items-center justify-center gap-1 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
              >
                <XCircle className="w-4 h-4" />
                Từ chối
              </button>
            </div>
          )}

          {status === "approved" && (
            <button
              onClick={() => handleStartService(booking)}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
            >
              <Play className="w-4 h-4" />
              Bắt đầu phục vụ
            </button>
          )}

          {status === "in_service" && (
            <button
              onClick={() => handleCompleteService(booking)}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium"
            >
              <CheckCheck className="w-4 h-4" />
              Hoàn tất dịch vụ
            </button>
          )}

          {status === "completed" && (
            <div className="flex items-center justify-center gap-1 px-3 py-2 bg-green-50 text-green-600 rounded-lg text-sm font-medium">
              <CheckCircle className="w-4 h-4" />
              Hoàn thành
              {booking.review && (
                <span className="ml-2 text-yellow-500">
                  {"★".repeat(booking.review.rating)}
                </span>
              )}
            </div>
          )}

          {status === "cancelled" && (
            <div className="bg-red-50 text-red-600 rounded-lg p-3 text-sm">
              <div className="flex items-center gap-1 font-medium mb-2">
                <XCircle className="w-4 h-4" />
                Đã hủy
              </div>
              {booking.rejectionReason && (
                <p className="text-xs text-red-500">
                  Lý do: {booking.rejectionReason}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    );
  };

  const KanbanColumn = ({ title, bookings, status, color }) => {
    return (
      <div className="flex-1 min-w-[280px]">
        <div className={`${color} text-white rounded-t-lg px-4 py-3`}>
          <h3 className="font-semibold">{title}</h3>
          <p className="text-sm opacity-90">{bookings.length} đơn</p>
        </div>
        <div className="bg-gray-50 rounded-b-lg p-4 min-h-[500px] space-y-3">
          {bookings.map((booking) => (
            <BookingCard key={booking.id} booking={booking} status={status} />
          ))}
          {bookings.length === 0 && (
            <p className="text-gray-400 text-center py-8 text-sm">
              Không có đơn hàng
            </p>
          )}
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <ProviderLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Đang tải...</p>
          </div>
        </div>
      </ProviderLayout>
    );
  }

  return (
    <ProviderLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Quản lý Đơn Đặt Dịch Vụ
            </h1>
            <p className="text-gray-600">
              Quản lý và cập nhật trạng thái đơn hàng
            </p>
          </div>
          <ClipboardList className="w-10 h-10 text-purple-600" />
        </div>

        <div className="flex gap-4 overflow-x-auto pb-4">
          <KanbanColumn
            title="Chờ duyệt"
            bookings={bookings.pending}
            status="pending"
            color="bg-yellow-500"
          />
          <KanbanColumn
            title="Đã duyệt"
            bookings={bookings.approved}
            status="approved"
            color="bg-blue-500"
          />
          <KanbanColumn
            title="Đang phục vụ"
            bookings={bookings.in_service}
            status="in_service"
            color="bg-purple-500"
          />
          <KanbanColumn
            title="Hoàn tất"
            bookings={bookings.completed}
            status="completed"
            color="bg-green-500"
          />
          <KanbanColumn
            title="Đã hủy"
            bookings={bookings.cancelled}
            status="cancelled"
            color="bg-red-500"
          />
        </div>

        {/* Reject Modal */}
        {rejectModal.open && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl max-w-md w-full p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-900">
                  Từ chối đơn hàng
                </h3>
                <button
                  onClick={() => {
                    setRejectModal({ open: false, booking: null });
                    setRejectReason("");
                  }}
                  className="p-1 hover:bg-gray-100 rounded"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <p className="text-gray-600 mb-4">
                Khách hàng sẽ được hoàn tiền. Vui lòng nhập lý do từ chối:
              </p>

              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="VD: Tôi không còn thời gian trống..."
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none mb-4"
              />

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setRejectModal({ open: false, booking: null });
                    setRejectReason("");
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Hủy
                </button>
                <button
                  onClick={handleRejectConfirm}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  Xác nhận từ chối
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProviderLayout>
  );
};

export default ProviderBookingsPage;