import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Plus, Edit, Trash2, Search, Power } from "lucide-react";
import { toast } from "react-toastify";
import ProviderLayout from "../../layouts/ProviderLayout";
import {
  getProviderServices,
  deleteService,
  toggleServiceStatus,
} from "../../services/providerService";

const ProviderServicesPage = () => {
  const navigate = useNavigate();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [serviceToDelete, setServiceToDelete] = useState(null);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const response = await getProviderServices();
      if (response.status === 200) {
        setServices(response.data || generateMockServices());
      } else {
        setServices(generateMockServices());
      }
    } catch (error) {
      console.error("Fetch services error:", error);
      setServices(generateMockServices());
    } finally {
      setLoading(false);
    }
  };

  const generateMockServices = () => {
    return [
      {
        id: 1,
        name: "Cắt tóc nam",
        price: 150000,
        duration: 30,
        status: "active",
        image: "https://via.placeholder.com/100",
      },
      {
        id: 2,
        name: "Nhuộm tóc",
        price: 500000,
        duration: 120,
        status: "active",
        image: "https://via.placeholder.com/100",
      },
    ];
  };

  const handleToggleStatus = async (service) => {
    // 1. Xác định trạng thái hiện tại (ưu tiên isActive nếu DB dùng boolean)
    const currentStatus = service.isActive;
    const nextStatus = !currentStatus; // Đảo ngược trạng thái

    try {
      // 2. Truyền nextStatus vào API.
      // Nếu API của bạn nhận 'active'/'inactive' thì convert ở đây:
      const statusPayload = nextStatus ? "active" : "inactive";

      const response = await toggleServiceStatus(service.id, statusPayload);

      if (response.status === 200) {
        toast.success(`Đã ${nextStatus ? "bật" : "tắt"} dịch vụ`);
        fetchServices(); // Refresh lại danh sách
      } else {
        toast.error("Có lỗi xảy ra");
      }
    } catch (error) {
      console.error("Toggle status error:", error);
      toast.error("Có lỗi xảy ra");
    }
  };

  const handleDeleteClick = (service) => {
    setServiceToDelete(service);
    setDeleteModalOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!serviceToDelete) return;

    try {
      const response = await deleteService(serviceToDelete.id);
      if (response.status === 200) {
        toast.success("Đã xóa dịch vụ");
        fetchServices();
        setDeleteModalOpen(false);
        setServiceToDelete(null);
      } else {
        toast.error("Xóa không thành công do đang đã được booking");
      }
    } catch (error) {
      console.error("Delete service error:", error);
      toast.error("Có lỗi xảy ra");
    }
  };

  const filteredServices = services.filter((service) =>
    service.name.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(amount);
  };

  if (loading) {
    return (
      <ProviderLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Đang tải...</p>
          </div>
        </div>
      </ProviderLayout>
    );
  }

  return (
    <ProviderLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Quản lý Dịch vụ
            </h1>
            <p className="text-gray-600">Quản lý danh sách dịch vụ của bạn</p>
          </div>
          <Link
            to="/provider/services/new"
            className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg font-medium"
          >
            <Plus className="w-5 h-5" />
            Thêm dịch vụ mới
          </Link>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Tìm kiếm dịch vụ..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Services Table */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                    Dịch vụ
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                    Giá
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                    Thời lượng
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                    Trạng thái
                  </th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">
                    Thao tác
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredServices.length > 0 ? (
                  filteredServices.map((service) => (
                    <tr
                      key={service.id}
                      className="hover:bg-gray-50 transition-colors"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              service.images[0].imageUrl ||
                              "https://via.placeholder.com/60"
                            }
                            alt={service.name}
                            className="w-14 h-14 rounded-lg object-cover"
                          />
                          <span className="font-medium text-gray-900">
                            {service.name}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-900 font-medium">
                        {formatCurrency(service.price)}
                      </td>
                      <td className="px-6 py-4 text-gray-700">
                        {service.duration} phút
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => handleToggleStatus(service)}
                          className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                            service.isActive
                              ? "bg-green-100 text-green-700 hover:bg-green-200"
                              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                          }`}
                        >
                          <Power className="w-4 h-4" />
                          {service.isActive ? "Kích hoạt" : "Vô hiệu hóa"}
                        </button>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() =>
                              navigate(`/provider/services/edit/${service.id}`)
                            }
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Chỉnh sửa"
                          >
                            <Edit className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteClick(service)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Xóa"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="px-6 py-12 text-center">
                      <div className="text-gray-500">
                        <p className="mb-2">Không tìm thấy dịch vụ nào</p>
                        <Link
                          to="/provider/services/new"
                          className="text-purple-600 hover:text-purple-700 font-medium"
                        >
                          Thêm dịch vụ đầu tiên
                        </Link>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Delete Confirmation Modal */}
        {deleteModalOpen && serviceToDelete && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl max-w-md w-full p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Xác nhận xóa
              </h3>
              <p className="text-gray-600 mb-6">
                Bạn có chắc chắn muốn xóa dịch vụ{" "}
                <strong>"{serviceToDelete.name}"</strong>? Hành động này không
                thể hoàn tác.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setDeleteModalOpen(false);
                    setServiceToDelete(null);
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Hủy
                </button>
                <button
                  onClick={handleDeleteConfirm}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  Xóa
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProviderLayout>
  );
};

export default ProviderServicesPage;
