import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { ArrowLeft, UserCircle, Calendar, Clock, MapPin, Phone, Mail, CheckCircle } from 'lucide-react';
import ProviderLayout from '../../layouts/ProviderLayout';
import { getProviderBookings, checkInBooking, completeBooking, rateCustomer } from '../../services/providerService';

const ProviderBookingDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [customerRating, setCustomerRating] = useState({
    punctuality: 5,
    attitude: 5,
    comment: ''
  });

  useEffect(() => {
    fetchBookingDetail();
  }, [id]);

  const fetchBookingDetail = async () => {
    try {
      const response = await getProviderBookings();
      if (response.status === 200) {
        const foundBooking = response.data?.find(b => b.id === parseInt(id));
        setBooking(foundBooking || generateMockBooking());
      } else {
        setBooking(generateMockBooking());
      }
    } catch (error) {
      console.error('Fetch booking error:', error);
      setBooking(generateMockBooking());
    } finally {
      setLoading(false);
    }
  };

  const generateMockBooking = () => ({
    id: 1,
    customer: {
      fullName: 'Nguyễn Văn A',
      email: 'a@example.com',
      phone: '0123456789'
    },
    service: { name: 'Cắt tóc nam', price: 150000 },
    bookingTime: new Date().toISOString(),
    status: 'approved',
    notes: 'Khách muốn cắt tóc ngắn'
  });

  const handleCheckIn = async () => {
    try {
      const response = await checkInBooking(id);
      if (response.status === 200) {
        toast.success('Đã check-in thành công');
        fetchBookingDetail();
      } else {
        toast.error('Có lỗi xảy ra');
      }
    } catch (error) {
      console.error('Check-in error:', error);
      toast.error('Có lỗi xảy ra');
    }
  };

  const handleComplete = async () => {
    try {
      const response = await completeBooking(id);
      if (response.status === 200) {
        toast.success('Đã hoàn tất dịch vụ');
        setShowRatingModal(true);
      } else {
        toast.error('Có lỗi xảy ra');
      }
    } catch (error) {
      console.error('Complete error:', error);
      toast.error('Có lỗi xảy ra');
    }
  };

  const handleSubmitRating = async () => {
    try {
      const response = await rateCustomer(id, customerRating);
      if (response.status === 200) {
        toast.success('Đã đánh giá khách hàng');
        setShowRatingModal(false);
        navigate('/provider/bookings');
      } else {
        toast.error('Có lỗi xảy ra');
      }
    } catch (error) {
      console.error('Rate customer error:', error);
      toast.error('Có lỗi xảy ra');
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      pending: 'bg-yellow-100 text-yellow-700',
      approved: 'bg-blue-100 text-blue-700',
      in_service: 'bg-purple-100 text-purple-700',
      completed: 'bg-green-100 text-green-700',
      canceled: 'bg-red-100 text-red-700'
    };
    const texts = {
      pending: 'Chờ duyệt',
      approved: 'Đã duyệt',
      in_service: 'Đang phục vụ',
      completed: 'Hoàn tất',
      canceled: 'Đã hủy'
    };
    return (
      <span className={`px-3 py-1 rounded-full text-sm font-medium ${badges[status]}`}>
        {texts[status]}
      </span>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  if (loading) {
    return (
      <ProviderLayout>
        <div className="flex items-center justify-center h-64">
          <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </ProviderLayout>
    );
  }

  if (!booking) {
    return (
      <ProviderLayout>
        <div className="text-center py-12">
          <p className="text-gray-600">Không tìm thấy đơn hàng</p>
        </div>
      </ProviderLayout>
    );
  }

  return (
    <ProviderLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <button
            onClick={() => navigate('/provider/bookings')}
            className="flex items-center gap-2 text-purple-600 hover:text-purple-700 font-medium mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Quay lại
          </button>
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-gray-900">
              Chi tiết Đơn hàng #{booking.id}
            </h1>
            {getStatusBadge(booking.status)}
          </div>
        </div>

        {/* Customer Info */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <UserCircle className="w-6 h-6 text-purple-600" />
            Thông tin Khách hàng
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Họ và tên</p>
              <p className="font-semibold text-gray-900">{booking.user?.fullName}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 flex items-center gap-1">
                <Mail className="w-4 h-4" /> Email
              </p>
              <p className="text-gray-900">{booking.user?.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 flex items-center gap-1">
                <Phone className="w-4 h-4" /> Số điện thoại
              </p>
              <p className="text-gray-900">{booking.user?.phone || 'Chưa cập nhật'}</p>
            </div>
          </div>
        </div>

        {/* Service Info */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Thông tin Dịch vụ</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-3 border-b">
              <span className="text-gray-700">Dịch vụ</span>
              <span className="font-semibold text-gray-900">{booking.service?.name}</span>
            </div>
            <div className="flex items-center justify-between pb-3 border-b">
              <span className="text-gray-700 flex items-center gap-1">
                <Calendar className="w-4 h-4" /> Ngày đặt
              </span>
              <span className="font-semibold text-gray-900">
                {new Date(booking.createdAt).toLocaleDateString('vi-VN')}
              </span>
            </div>
            <div className="flex items-center justify-between pb-3 border-b">
              <span className="text-gray-700 flex items-center gap-1">
                <Clock className="w-4 h-4" /> Giờ
              </span>
              <span className="font-semibold text-gray-900">
                {new Date(booking.createdAt).toLocaleTimeString('vi-VN', {
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Giá</span>
              <span className="font-bold text-purple-600 text-lg">
                {formatCurrency(booking.service?.price)}
              </span>
            </div>
          </div>
        </div>

        {/* Notes */}
        {booking.notes && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h3 className="font-semibold text-blue-900 mb-2">Ghi chú từ khách hàng</h3>
            <p className="text-blue-700">{booking.notes}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-4">
          {booking.status === 'approved' && (
            <button
              onClick={handleCheckIn}
              className="flex-1 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Check-in (Bắt đầu làm)
            </button>
          )}
          {booking.status === 'in_service' && (
            <button
              onClick={handleComplete}
              className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Hoàn tất dịch vụ
            </button>
          )}
        </div>

        {/* Rating Modal */}
        {showRatingModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl max-w-md w-full p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Đánh giá Khách hàng</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Khách có đến đúng giờ không? (1-5 sao)
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    value={customerRating.punctuality}
                    onChange={(e) =>
                      setCustomerRating({ ...customerRating, punctuality: parseInt(e.target.value) })
                    }
                    className="w-full"
                  />
                  <p className="text-center font-semibold text-purple-600">{customerRating.punctuality} sao</p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Thái độ của khách (1-5 sao)
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    value={customerRating.attitude}
                    onChange={(e) =>
                      setCustomerRating({ ...customerRating, attitude: parseInt(e.target.value) })
                    }
                    className="w-full"
                  />
                  <p className="text-center font-semibold text-purple-600">{customerRating.attitude} sao</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nhận xét
                  </label>
                  <textarea
                    value={customerRating.comment}
                    onChange={(e) =>
                      setCustomerRating({ ...customerRating, comment: e.target.value })
                    }
                    placeholder="Nhập nhận xét về khách hàng..."
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 resize-none"
                  />
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setShowRatingModal(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Bỏ qua
                  </button>
                  <button
                    onClick={handleSubmitRating}
                    className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                  >
                    Gửi đánh giá
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProviderLayout>
  );
};

export default ProviderBookingDetailPage;
