import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CheckCircle, AlertCircle, Upload, FileText } from "lucide-react";
import { toast } from "react-toastify";
import ProviderLayout from "../../layouts/ProviderLayout";
import DragDropUpload from "../../components/DragDropUpload";
import { uploadKYCDocuments } from "../../services/providerService.js";
const ProviderKYCPage = () => {
  const navigate = useNavigate();
  const [businessLicense, setBusinessLicense] = useState([]);
  const [idCardFront, setIdCardFront] = useState([]);
  const [idCardBack, setIdCardBack] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [kycStatus, setKycStatus] = useState("pending"); // pending, verified, rejected

  const handleSubmit = async () => {
    // 1. Validation (Giữ nguyên)
    if (
      businessLicense.length === 0 ||
      idCardFront.length === 0 ||
      idCardBack.length === 0
    ) {
      toast.error("Vui lòng upload đầy đủ tài liệu");
      return;
    }

    setIsSubmitting(true);

    try {
      // 2. Hàm helper để tạo request cho từng file
      const uploadSingle = (file, type) => {
        const formData = new FormData();
        formData.append("document", file); // Key phải là 'document' như Backend quy định
        formData.append("type", type); // Gửi kèm type
        return uploadKYCDocuments(formData);
      };

      // 3. Gửi đồng thời cả 3 request
      await Promise.all([
        uploadSingle(businessLicense[0], "BUSINESS_LICENSE"),
        uploadSingle(idCardFront[0], "CITIZEN_ID_FRONT"),
        uploadSingle(idCardBack[0], "CITIZEN_ID_BACK"),
      ]);

      toast.success("Đã gửi toàn bộ tài liệu xác thực thành công!");
      setKycStatus("verified");
      setTimeout(() => navigate("/provider/dashboard"), 2000);
    } catch (error) {
      console.error("KYC Upload Error:", error);
      toast.error(
        "Có lỗi xảy ra khi upload. Có thể một số file đã tồn tại hoặc lỗi mạng.",
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStatusBadge = () => {
    const badges = {
      pending: {
        color: "bg-yellow-100 text-yellow-700 border-yellow-300",
        icon: AlertCircle,
        text: "Chờ xác thực",
      },
      verified: {
        color: "bg-green-100 text-green-700 border-green-300",
        icon: CheckCircle,
        text: "Đã xác thực",
      },
      rejected: {
        color: "bg-red-100 text-red-700 border-red-300",
        icon: AlertCircle,
        text: "Từ chối",
      },
    };

    const status = badges[kycStatus];
    const Icon = status.icon;

    return (
      <div
        className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border ${status.color}`}
      >
        <Icon className="w-5 h-5" />
        <span className="font-semibold">{status.text}</span>
      </div>
    );
  };

  return (
    <ProviderLayout>
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Xác thực KYC
              </h1>
              <p className="text-gray-600">
                Upload các tài liệu cần thiết để xác thực tài khoản Provider
              </p>
            </div>
            {getStatusBadge()}
          </div>
        </div>

        {/* Info Alert */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8">
          <div className="flex gap-3">
            <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-1">
                Yêu cầu tài liệu
              </h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Giấy phép Kinh doanh (hợp lệ)</li>
                <li>• CCCD/CMND mặt trước (rõ ràng, không mờ)</li>
                <li>• CCCD/CMND mặt sau (rõ ràng, không mờ)</li>
                <li>• Định dạng: JPG, PNG hoặc PDF. Tối đa 5MB/file</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Upload Sections */}
        <div className="space-y-6">
          {/* Business License */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              1. Giấy phép Kinh doanh
            </h3>
            <DragDropUpload
              label=""
              files={businessLicense}
              onFilesChange={setBusinessLicense}
              multiple={false}
            />
          </div>

          {/* ID Card Front */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              2. CCCD/CMND Mặt trước
            </h3>
            <DragDropUpload
              label=""
              files={idCardFront}
              onFilesChange={setIdCardFront}
              multiple={false}
            />
          </div>

          {/* ID Card Back */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              3. CCCD/CMND Mặt sau
            </h3>
            <DragDropUpload
              label=""
              files={idCardBack}
              onFilesChange={setIdCardBack}
              multiple={false}
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-8 flex gap-4">
          <button
            onClick={() => navigate("/provider/dashboard")}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
          >
            Hủy
          </button>
          <button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium shadow-lg"
          >
            {isSubmitting ? (
              <span className="flex items-center justify-center gap-2">
                <Upload className="w-5 h-5 animate-bounce" />
                Đang upload...
              </span>
            ) : (
              "Gửi tài liệu xác thực"
            )}
          </button>
        </div>
      </div>
    </ProviderLayout>
  );
};

export default ProviderKYCPage;
