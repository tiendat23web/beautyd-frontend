import { baseURL } from "./baseAPI"

export const getNotifications = async () => {
    try {
        const response = await baseURL.get("/notifications");
        return response;
    } catch (error) {
        console.error('Get Notifications error:', error);
        return { success: false, message: error.message };
    }
}
export const markAsRead = async (notificationId) => {
    try {
        const response = await baseURL.put(`/notifications/${notificationId}/read`);
        return response;
    }
    catch (error) {
        console.error('Mark as Read error:', error);
        return { success: false, message: error.message };
    }
};
export const deleteNotification = async (notificationId) => {
    try {
        const response = await baseURL.delete(`/notifications/${notificationId}`);
        return response;
    }
    catch (error) {
        console.error('Delete Notification error:', error);
        return { success: false, message: error.message };
    }
};

export const markMultipleAsRead = async (ids) => {
    try {
        const response = await baseURL.patch("/notifications/mark-multiple-read", { ids });
        return response;
    }
    catch (error) {
        console.error('Mark All as Read error:', error);
        return { success: false, message: error.message };
    }
};