import { baseURL } from "./baseAPI";

// NOTE: KYC upload is handled via /api/kyc/upload, not provider routes
export const uploadKYCDocuments = async (formData) => {
    try {
        const response = await baseURL.post('/kyc/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response;
    }
    catch (error) {
        console.error('KYC Upload error:', error);
        return { success: false, message: error.message };
    }
};

// Get Provider Dashboard Statistics
export const getProviderStats = async () => {
    try {
        const response = await baseURL.get('/provider/stats');
        return response;
    } catch (error) {
        console.error('Get Provider Stats error:', error);
        return { success: false, message: error.message };
    }
};

// Get Provider's Services
export const getProviderServices = async () => {
    try {
        const response = await baseURL.get('/provider/services');
        return response;
    } catch (error) {
        console.error('Get Provider Services error:', error);
        return { success: false, message: error.message };
    }
};

// Create New Service
export const createService = async (serviceData) => {
    try {
        const response = await baseURL.post('/provider/services', serviceData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response;
    } catch (error) {
        console.error('Create Service error:', error);
        return { success: false, message: error.message };
    }
};

// Update Service
export const updateService = async (id, serviceData) => {
    try {
        const response = await baseURL.put(`/provider/services/${id}`, serviceData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response;
    } catch (error) {
        console.error('Update Service error:', error);
        return { success: false, message: error.message };
    }
};

// Delete Service
export const deleteService = async (id) => {
    try {
        const response = await baseURL.delete(`/provider/services/${id}`);
        return response;
    } catch (error) {
        console.error('Delete Service error:', error);
        return { success: false, message: error.message };
    }
};

// Toggle Service Status
export const toggleServiceStatus = async (id, status) => {
    try {
        const response = await baseURL.patch(`/provider/services/${id}/status`, { status });
        return response;
    } catch (error) {
        console.error('Toggle Service Status error:', error);
        return { success: false, message: error.message };
    }
};

export const updateBookingStatus = async (id, status) => {
    try {
        const response = await baseURL.post(`/provider/bookings/${id}/update-status`, { status });
        return response;
    } catch (error) {
        console.error('Update Booking Status error:', error);
        return { success: false, message: error.message };
    }
};

// Get Provider Bookings
export const getProviderBookings = async (status) => {
    try {
        const response = await baseURL.get('/provider/bookings', {
            params: status ? { status } : {}
        });
        return response;
    } catch (error) {
        console.error('Get Provider Bookings error:', error);
        return { success: false, message: error.message };
    }
};

// Accept Booking
export const acceptBooking = async (id) => {
    try {
        const response = await baseURL.post(`/provider/bookings/${id}/accept`);
        return response;
    } catch (error) {
        console.error('Accept Booking error:', error);
        return { success: false, message: error.message };
    }
};

// Reject Booking
export const rejectBooking = async (id, reason) => {
    try {
        const response = await baseURL.post(`/provider/bookings/${id}/reject`, { reason });
        return response;
    } catch (error) {
        console.error('Reject Booking error:', error);
        return { success: false, message: error.message };
    }
};

// Check-in Booking (Start Service)
export const checkInBooking = async (id) => {
    try {
        const response = await baseURL.post(`/provider/bookings/${id}/checkin`);
        return response;
    } catch (error) {
        console.error('Check-in Booking error:', error);
        return { success: false, message: error.message };
    }
};

// Complete Booking
export const completeBooking = async (id) => {
    try {
        const response = await baseURL.post(`/provider/bookings/${id}/complete`);
        return response;
    } catch (error) {
        console.error('Complete Booking error:', error);
        return { success: false, message: error.message };
    }
};

// Get Provider Reviews
export const getProviderReviews = async () => {
    try {
        const response = await baseURL.get('/provider/reviews');
        return response;
    } catch (error) {
        console.error('Get Provider Reviews error:', error);
        return { success: false, message: error.message };
    }
};

// Reply to Review
export const replyToReview = async (reviewId, reply) => {
    try {
        const response = await baseURL.post(`/provider/reviews/${reviewId}/reply`, { reply });
        return response;
    } catch (error) {
        console.error('Reply to Review error:', error);
        return { success: false, message: error.message };
    }
};

// Report Review
export const reportReview = async (reviewId, reason) => {
    try {
        const response = await baseURL.post(`/provider/reviews/${reviewId}/report`, { reason });
        return response;
    } catch (error) {
        console.error('Report Review error:', error);
        return { success: false, message: error.message };
    }
};

// Rate Customer
export const rateCustomer = async (bookingId, rating) => {
    try {
        const response = await baseURL.post(`/provider/bookings/${bookingId}/rate-customer`, rating);
        return response;
    } catch (error) {
        console.error('Rate Customer error:', error);
        return { success: false, message: error.message };
    }
};

// Get Calendar Events
export const getCalendarEvents = async (start, end) => {
    try {
        const response = await baseURL.get('/provider/calendar', {
            params: { start, end }
        });
        return response;
    } catch (error) {
        console.error('Get Calendar Events error:', error);
        return { success: false, message: error.message };
    }
};

// Block Time Slot
export const blockTimeSlot = async (timeSlotData) => {
    try {
        const response = await baseURL.post('/provider/calendar/block', timeSlotData);
        return response;
    } catch (error) {
        console.error('Block Time Slot error:', error);
        return { success: false, message: error.message };
    }
};

// Remove Blocked Time
export const removeBlockedTime = async (id) => {
    try {
        const response = await baseURL.delete(`/provider/calendar/block/${id}`);
        return response;
    } catch (error) {
        console.error('Remove Blocked Time error:', error);
        return { success: false, message: error.message };
    }
};
