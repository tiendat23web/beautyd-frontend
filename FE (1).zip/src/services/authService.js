import { baseURL } from "./baseAPI";

export const loginUser = async (email, password) => {
    try {
        const response = await baseURL.post('/auth/login', { email, password });
        return response;
    } catch (error) {
        console.error('Login error:', error);
        return { success: false, message: error.message };
    }
};

export const registerUser = async (data) => {
    try {
        const response = await baseURL.post('/auth/register', data);
        return response;
    } catch (error) {
        console.error('Register error:', error);
        return { success: false, message: error.message };
    }
};
export const checkEmailExists = async (email) => {
    try {
        const response = await baseURL.post('/auth/check-email', { email });
        return response;
    } catch (error) {
        console.error('Check Email error:', error);
        return { success: false, message: error.message };
    }
};

export const forgetPassword = async (email, newPassword) => {
    try {
        const response = await baseURL.post('/auth/forget-password', { email, newPassword });
        return response;
    }
    catch (error) {
        console.error('Forget Password error:', error);
        return { success: false, message: error.message };
    }
};

export const getProfile = async () => {
    try {
        const response = await baseURL.get('/users/profile');
        return response;
    } catch (error) {
        console.error('Get Profile error:', error);
        return { success: false, message: error.message };
    }
};

export const editProfile = async (data) => {
    try {
        const response = await baseURL.put('/users/profile', data);
        return response;
    } catch (error) {
        console.error('Edit Profile error:', error);
        return { success: false, message: error.message };
    }
};